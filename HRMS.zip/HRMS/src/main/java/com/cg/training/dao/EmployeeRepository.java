package com.cg.training.dao;

import java.time.LocalDate;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.cg.training.entities.Employee;
import com.cg.training.entities.Gender;

@Repository
public interface EmployeeRepository extends JpaRepository<Employee, Integer> {


	 

	    // Containing , Contains, IsContaning

	 

	    List<Employee> findByFirstNameContains(String firstName);

	 

	    List<Employee> findByLastNameContains(String lastName);

	 

	    @Query("SELECT E FROM Employee E WHERE E.gender=?1")
	    List<Employee> findByGenderContains(Gender gender);

	 

	    List<Employee> findByHireDate(LocalDate hireDate);

	    List<Employee> findByBirthDate(LocalDate birthDate);

	 

	    @Query("SELECT E FROM Employee E ORDER BY E.hireDate DESC")
	    List<Employee> findAllByOrderByHireDateDesc(); 
}
















































//OrderBy clause in JPA- it's like a built-in method
