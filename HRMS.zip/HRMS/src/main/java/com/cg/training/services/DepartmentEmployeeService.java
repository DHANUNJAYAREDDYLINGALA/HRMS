package com.cg.training.services;

import java.time.LocalDate;
import java.util.List;

import com.cg.training.entities.DepartmentEmployee;

public interface DepartmentEmployeeService {
	public List<DepartmentEmployee> getdepartmentemployee();
	public List<DepartmentEmployee> findByDeptNoAndFromDate(String deptNo, LocalDate fromDate);
	public DepartmentEmployee findBysDeptNoAndFromDate(String deptNo, LocalDate fromDate);
	public DepartmentEmployee findByempNoAndFromDate(int empNo, LocalDate fromDate);
	public DepartmentEmployee getDepartEmployeeByEmpNoAndDeptNo(int empNo, String deptNo);
	public DepartmentEmployee getDepartmentEmployeeByEmpNoAndDeptNoAndFromDate(int empNo, String deptNo, LocalDate fromDate);
	public DepartmentEmployee updateDepartmentEmployee(DepartmentEmployee departmentEmployee);
	public DepartmentEmployee saveDepartmentEmployee(DepartmentEmployee departmentEmployee);
	public void deleteByEmpNoAndDeptNoAndFromDate(int empNo, LocalDate fromDate, String deptNo);
	public void deleteByEmpNoAndDeptNo(int empNo, String deptNo);
	public void deleteByEmpNoAndFromDate(int empNo, LocalDate fromDate);
	public void deleteByDeptNoAndFromDate(String deptNo, LocalDate fromDate);
	 
	
}
