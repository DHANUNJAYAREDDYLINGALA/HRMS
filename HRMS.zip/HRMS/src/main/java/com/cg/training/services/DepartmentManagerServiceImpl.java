package com.cg.training.services;

import java.time.LocalDate;
import java.util.List;

import org.slf4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cg.training.dao.DepartmentManagerRepository;
import com.cg.training.entities.DepartmentManager;
import com.cg.training.loggers.GlobalLoggers;

/**
 * This class implements the DepartmentManagerService interface and provides the business logic for managing department managers.
 */
@Service
public class DepartmentManagerServiceImpl implements DepartmentManagerService{

	@Autowired
	private DepartmentManagerRepository departmentManagerRespository;
	private Logger logger = GlobalLoggers.getLogger(DepartmentManagerServiceImpl.class);

	/**
     * Retrieves all department managers.
     *
     * @return A list of department managers.
     */
	public List<DepartmentManager> getDepartmentManager() {
		String methodName = "Getdeptmanager()";
        logger.info(methodName + "called");
		return departmentManagerRespository.findAll();
	}

	/**
     * Retrieves a department manager by employee number and department number.
     *
     * @param empNo  The employee number.
     * @param deptNo The department number.
     * @return The department manager matching the given criteria.
     */
	public DepartmentManager getDepartmentManagersByEmpNoAndDeptNo(int empNo, String deptNo) {
		String methodName = "Getbyemp_empnoAnddept_deptno(empno,deptno)";
        logger.info(methodName + "called");
		return departmentManagerRespository.findByEmployee_EmpNoAndDepartment_DeptNo(empNo, deptNo);
	}

	/**
     * Retrieves department managers by department number and from date.
     *
     * @param deptNo   The department number.
     * @param fromDate The from date.
     * @return A list of department managers matching the given criteria.
     */
	public List<DepartmentManager> findByDeptNoAndFromDate(String deptNo, LocalDate fromDate) {
		String methodName = "Getbydept_deptnoAndfromdate(fromdate,deptno)";
        logger.info(methodName + "called");
		return departmentManagerRespository.findByDepartmentDeptNoAndFromDate(deptNo, fromDate);
	}
	
	/**
     * Retrieves a department manager by employee number and from date.
     *
     * @param empNo    The employee number.
     * @param fromDate The from date.
     * @return The department manager matching the given criteria.
     */
	public DepartmentManager findByEmpNoAndFromDate(int empNo, LocalDate fromDate) {
		String methodName = "Getbyemp_empnoAndfromdate(empno,fromdate)";
        logger.info(methodName + "called");
		return departmentManagerRespository.findByEmployee_EmpNoAndFromDate(empNo, fromDate);
	}

	/**
     * Retrieves a department manager by employee number, department number, and from date.
     *
     * @param empNo    The employee number.
     * @param deptNo   The department number.
     * @param fromdate The from date.
     * @return The department manager matching the given criteria.
     */
	public DepartmentManager getDepartmentManagersByEmpNoAndDeptNoAndFromDate(int empNo, String deptNo,
			LocalDate fromdate) {
		String methodName = "Getbyemp_empnoAnddept_deptnoAndfromdate(empno,deptno,fromdate)";
        logger.info(methodName + "called");
		return departmentManagerRespository.findByEmployee_EmpNoAndDepartment_DeptNoAndFromDate(empNo, deptNo, fromdate);
	}

	/**
     * Saves a new department manager.
     *
     * @param departmentManager The department manager to be saved.
     * @return The saved department manager.
     */
	public DepartmentManager saveDepartmentManager(DepartmentManager departmentManager) {
		String methodName = "Savedeptmanager(departmentManager)";
        logger.info(methodName + "called");
		if (departmentManager != null)
			return departmentManagerRespository.save(departmentManager);
		else
			return null;
	}
	
	/**
     * Updates an existing department manager by employee number and department number.
     *
     * @param departmentManager The department manager to be updated.
     * @return The updated department manager.
     */	
	public DepartmentManager updateByEmpNoAndDeptNo(DepartmentManager departmentManager) {
		String methodName = "UpdatebyempnoAnddeptno(departmentManager)";
        logger.info(methodName + "called");
		if (departmentManager != null)
			return departmentManagerRespository.save(departmentManager);
		else
			return null;
	}

	/**
     * Updates an existing department manager by employee number and from date.
     *
     * @param departmentManager The department manager to be updated.
     * @return The updated department manager.
     */
	public DepartmentManager updateByEmpNoAndFromDate(DepartmentManager departmentManager) {
		String methodName = "UpdatebyempnoAndfromdate(departmentManager)";
        logger.info(methodName + "called");
		if (departmentManager != null)
			return departmentManagerRespository.save(departmentManager);
		else
			return null;
	}

	/**
     * Updates an existing department manager by department number and from date.
     *
     * @param departmentManager The department manager to be updated.
     * @return The updated department manager.
     */
	public DepartmentManager updateByDeptNoAndFromDate(DepartmentManager departmentManager) {
		String methodName = "UpdatebydeptnoAndfromdate(departmentManager)";
        logger.info(methodName + "called");
		if (departmentManager != null)
			return departmentManagerRespository.save(departmentManager);
		else
			return null;
	}

	/**
     * Updates an existing department manager by employee number, department number, and from date.
     *
     * @param departmentManager The department manager to be updated.
     * @return The updated department manager.
     */
	public DepartmentManager updateByEmpNoAndDeptNoAndFromDate(DepartmentManager departmentManager) {
		String methodName = "UpdatebyempnoAnddeptnoAndfromdate(departmentManager)";
        logger.info(methodName + "called");
		if (departmentManager != null)
			return departmentManagerRespository.save(departmentManager);
		else
			return null;
	}

	/**
     * Updates an existing department manager by department number and from date.
     *
     * @param departmentManager The department manager to be updated.
     * @return The updated department manager.
     */
	public DepartmentManager updatebydeptnoAndfromdate(DepartmentManager departmentManager) {
		String methodName = "UpdatebydeptnoAndfromdate(departmentManager)";
        logger.info(methodName + "called");
		return departmentManagerRespository.save(departmentManager);
	}

	/**
     * Updates an existing department manager by employee number, department number, and from date.
     *
     * @param departmentManager The department manager to be updated.
     * @return The updated department manager.
     */
	public DepartmentManager updatebyempnoAnddeptnoAndfromdate(DepartmentManager departmentManager) {
		String methodName = "UpdatebyempnoAnddeptnoAndfromdate(departmentManager)";
        logger.info(methodName + "called");
		return departmentManagerRespository.save(departmentManager);
	}

	/**
     * Deletes a department manager by employee number, department number, and from date.
     *
     * @param empNo    The employee number.
     * @param fromDate The from date.
     * @param deptNo   The department number.
     */
	@Transactional
	public void deleteByEmpNoAndDeptNoAndFromDate(int empNo, LocalDate fromDate, String deptNo) {
		String methodName = "DeletebyempnoAndddeptnoAndfromdate(empno,deptno,fromDate)";
        logger.info(methodName + "called");
		departmentManagerRespository.deleteByEmpNoAndDeptNoAndFromDate(empNo, deptNo, fromDate);
	}

	/**
     * Deletes department managers by employee number and department number.
     *
     * @param empNo  The employee number.
     * @param deptNo The department number.
     */
	@Transactional
	public void deleteByEmpNoAndDeptNo(int empNo, String deptNo) {
		String methodName = "DeletebyempnoAnddeptno(empno,deptno)";
        logger.info(methodName + "called");
		departmentManagerRespository.deleteByEmpNoAndDeptNo(empNo, deptNo);
	}

	/**
     * Deletes department managers by employee number and from date.
     *
     * @param empNo    The employee number.
     * @param fromDate The from date.
     */
	@Transactional
	public void deleteByEmpNoAndFromDate(int empNo, LocalDate fromDate) {
		String methodName = "DeletebyempnoAndfromdate(empno,fromDate)";
        logger.info(methodName + "called");
		departmentManagerRespository.deleteByEmpNoAndFromDate(empNo, fromDate);
	}

	/**
     * Deletes department managers by department number and from date.
     *
     * @param deptNo   The department number.
     * @param fromDate The from date.
     */
	@Transactional
	public void deleteByDeptNoAndFromDate(String deptNo, LocalDate fromDate) {
		String methodName = "DeletebydeptnoAndfromdate(fromDate,deptno)";
        logger.info(methodName + "called");
		departmentManagerRespository.deleteByDeptNoAndFromDate(deptNo, fromDate);
	}

	/**
	 * Retrieves a department manager by employee number, department number, and from date.
	 *
	 * @param empNo    The employee number.
	 * @param deptNo   The department number.
	 * @param fromDate The from date.
	 * @return The department manager matching the given criteria.
	 */
	public DepartmentManager getDepartmentManagerByEmpNoAndDeptNoAndFromDate(int empNo, String deptNo, LocalDate fromDate) {
		String methodName = "Getbyemp_empnoAnddept_deptnoAndfromdate(empno,deptno,fromDate)";
        logger.info(methodName + "called");
		return departmentManagerRespository.findByEmployee_EmpNoAndDepartment_DeptNoAndFromDate(empNo, deptNo,
				fromDate);
	}

	/**
	 * Retrieves a department manager by department number and from date.
	 *
	 * @param deptNo   The department number.
	 * @param fromDate The from date.
	 * @return The department manager matching the given criteria.
	 */
	public DepartmentManager getDepartmentDeptNoAndFromDate(String deptNo, LocalDate fromDate) {
		String methodName = "Getbydept_deptnoAndfromdate(fromDate,deptno)";
        logger.info(methodName + "called");
		return departmentManagerRespository.findByDepartment_DeptNoAndFromDate(deptNo, fromDate);
	}

	/**
	 * Retrieves a department manager by employee number and department number.
	 *
	 * @param empNo  The employee number.
	 * @param deptNo The department number.
	 * @return The department manager matching the given criteria.
	 */
	public DepartmentManager getDepartmentManagerByEmpNoAndDeptNo(int empNo, String deptNo) {
		String methodName = "Getbyemp_empnoAnddept_deptno(empno,deptno)";
        logger.info(methodName + "called");
		return departmentManagerRespository.findByEmployee_EmpNoAndDepartment_DeptNo(empNo, deptNo);
	}

	/**
	 * Retrieves a department manager by employee number and from date.
	 *
	 * @param empNo    The employee number.
	 * @param fromDate The from date.
	 * @return The department manager matching the given criteria.
	 */
	public DepartmentManager getDepartmentManagerByEmpNoAndFromDate(int empNo, LocalDate fromDate) {
		String methodName = "Getbyemp_empnoAndfromdate(empno,fromDate)";
        logger.info(methodName + "called");
		return departmentManagerRespository.findByEmployee_EmpNoAndFromDate(empNo, fromDate);
	}

}
