package com.cg.training.controller;

import java.util.List;

import org.slf4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.cg.training.entities.Departments;
import com.cg.training.exceptions.InvalidDataException;
import com.cg.training.loggers.GlobalLoggers;
import com.cg.training.services.DepartmentServiceImpl;

import io.swagger.v3.oas.annotations.Operation;

//It contains various CRUD (Create, Read, Update, Delete) operations for managing departments.
@RestController
@RequestMapping("/api/v1/Departments")
public class DepartmentsController {
	
	@Autowired
    private DepartmentServiceImpl departmentServices;
	private Logger logger = GlobalLoggers.getLogger(DepartmentsController.class);
   
	//Retrieve a list of all departments.
	@GetMapping("/all")
    @Operation(summary = "Fetch all departments")
    public List<Departments> findAlldepartments() {
    	String methodName = "GetAll()";
        logger.info(methodName + "called");
        return departmentServices.getDepartments();
    }
	
    //Retrieve departments by department number.
    @GetMapping("/{deptNo}")
    @Operation(summary = "Search department by deptno")
    public List<Departments> findAllDepartmentsBydeptNo(@PathVariable("deptNo") String deptNo) {
    	String methodName = "GetDeptsByDeptNo(empNo,deptNo)";
        logger.info(methodName + "called");
        return departmentServices.getDepartmentsByDepNo(deptNo);
    }

  //Retrieve departments by department name.
    @GetMapping("/name/{deptName}")
    @Operation(summary = "Search department by name")
    public List<Departments> findAllDepartmentsByDeptName(@PathVariable("deptName") String deptName) {
    	String methodName = "GetDeptsByDeptName(deptName)";
        logger.info(methodName + "called");
    	return departmentServices.getDepartmentsByDeptName(deptName);
    }

    /*
     * Add a new department to the database.
     * If the department is successfully created, returns a success message with HTTP status 200 (OK).
	 *If the validation fails, throws an InvalidDataException with HTTP status 400 (Bad Request).
     */
    @PostMapping("/add")
    @Operation(summary = "Add new department")
    public ResponseEntity<String> addDepartmentManager(@RequestBody Departments departmentManager) {
    	String methodName = "AddDept()";
        logger.info(methodName + "called");
        Departments department = departmentServices.addDepartment(departmentManager);
        if (department != null) {
            return new ResponseEntity<String>("New department added successfully", HttpStatus.OK);
        } else
            throw new InvalidDataException("Validation Failed");
    }

    /*
     *  Update a department by department number.
     *  If the department exists, updates the department and returns a success message with HTTP status 200 (OK).
	 *If the department doesn't exist, throws an InvalidDataException with HTTP status 400 (Bad Request).
     */
    @PutMapping("/deptno/{deptNo}")
    @Operation(summary = "Update department by department deptno")
    public ResponseEntity<String> updateDepartmentByDeptNo(@PathVariable String deptNo,
            @RequestBody Departments departments) {
    	String methodName = "UpdateDeptsByDeptNo(deptNo)";
        logger.info(methodName + "called");
        Departments updatedManager = departmentServices.updateByDeptNo(departments);
        if (updatedManager != null) {
            return new ResponseEntity<String>("Department updated successfully", HttpStatus.OK);
        } else
            throw new InvalidDataException("Updation Failed");

 

    }
    
    /*
     * Update a department by department name.
     * If the department exists, updates the department and returns a success message with HTTP status 200 (OK).
	 *If the department doesn't exist, throws an InvalidDataException with HTTP status 400 (Bad Request).
     */
    @PutMapping("/deptname/{deptName}")
    @Operation(summary = "Update department by name")
    public ResponseEntity<String> updateDepartmentByDeptName(@PathVariable String deptName,
            @RequestBody Departments departments) {
    	String methodName = "UpdateDeptsByDeptName(deptName)";
        logger.info(methodName + "called");
        Departments updatedManager = departmentServices.updateByDeptName(departments);
        if (updatedManager != null)
            return new ResponseEntity<String>("Department updated successfully", HttpStatus.OK);
        else
            throw new InvalidDataException("Updation Failed");
    }
	
    
    /*
     * Delete a department by department number.
	 * Returns HTTP status 204 (No Content) if the deletion is successful.
     */
	 @DeleteMapping("deptNo/{deptNo}")
	    public ResponseEntity<Void> deleteDepartmentByDeptNo(@PathVariable String deptNo) {
		 String methodName = "DeleteDeptsByDeptNo(deptNo)";
	        logger.info(methodName + "called");
		 departmentServices.deleteByDeptNo(deptNo);
	        return ResponseEntity.noContent().build();
	    }
	
	 /*
	  * Delete a department by department name.
	  * Returns HTTP status 200 (OK) with a success message if the deletion is successful.
	  */
	 @DeleteMapping("/deptmentName/{deptName}")
	    public ResponseEntity<String> deleteDepartmentByDeptName(@RequestParam("deptName") String deptName) {
		 String methodName = "DeleteDeptsByDeptName(deptName)";
	        logger.info(methodName + "called");
		 departmentServices.deleteByDeptName(deptName);
	        return ResponseEntity.ok("Department deleted successfully");
	    }
	 
		
	


}
