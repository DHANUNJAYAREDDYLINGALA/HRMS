package com.cg.training.services;

import java.time.LocalDate;
import java.util.List;

import org.springframework.transaction.annotation.Transactional;

import com.cg.training.entities.Salaries;

public interface SalariesService {

	List<Salaries> getSalary();

	List<Salaries> getSalaryByFromDate(LocalDate fromDate);

	List<Salaries> getSalariesByEmployee(int empNo);

	List<Salaries> getSalaryByRange(int minSalary, int maxSalary);

	Salaries getSalaryByEmpNoandFromDate(int empNo, LocalDate fromDate);

	Salaries addSalary(Salaries salary);

	Salaries updateSalary(Salaries salary);

	Salaries getSalaryByFromDates(LocalDate fromDate);

	Salaries getSalariesByEmployees(int empNo);

	void deleteByEmpNoAndFromDate(int empNo, LocalDate fromDate);

	void deleteByFromDate(LocalDate fromDate);

	void deleteByEmpNo(int empNo);

}