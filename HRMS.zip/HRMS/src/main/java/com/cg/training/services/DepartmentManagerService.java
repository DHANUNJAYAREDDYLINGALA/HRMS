package com.cg.training.services;

import java.time.LocalDate;
import java.util.List;
import com.cg.training.entities.DepartmentManager;

public interface DepartmentManagerService {
	public List<DepartmentManager> getDepartmentManager();
	public DepartmentManager getDepartmentManagersByEmpNoAndDeptNo(int empNo, String deptNo) ;
	public List<DepartmentManager> findByDeptNoAndFromDate(String deptNo, LocalDate fromDate);
	public DepartmentManager findByEmpNoAndFromDate(int empNo, LocalDate fromDate);
	public DepartmentManager getDepartmentManagersByEmpNoAndDeptNoAndFromDate(int empNo, String deptNo,LocalDate fromdate);
	public DepartmentManager saveDepartmentManager(DepartmentManager departmentManager);
	public DepartmentManager updateByEmpNoAndDeptNo(DepartmentManager departmentManager);
	public DepartmentManager updateByEmpNoAndFromDate(DepartmentManager departmentManager);
	public DepartmentManager updateByDeptNoAndFromDate(DepartmentManager departmentManager);
	public DepartmentManager updateByEmpNoAndDeptNoAndFromDate(DepartmentManager departmentManager);
	public DepartmentManager updatebydeptnoAndfromdate(DepartmentManager departmentManager);
	public DepartmentManager updatebyempnoAnddeptnoAndfromdate(DepartmentManager departmentManager);
	public void deleteByEmpNoAndDeptNoAndFromDate(int empNo, LocalDate fromDate, String deptNo);
	public void deleteByEmpNoAndDeptNo(int empNo, String deptNo);
	public void deleteByEmpNoAndFromDate(int empNo, LocalDate fromDate);
	public void deleteByDeptNoAndFromDate(String deptNo, LocalDate fromDate);
	public DepartmentManager getDepartmentManagerByEmpNoAndDeptNoAndFromDate(int empNo, String deptNo, LocalDate fromDate);
	public DepartmentManager getDepartmentDeptNoAndFromDate(String deptNo, LocalDate fromDate);
	public DepartmentManager getDepartmentManagerByEmpNoAndDeptNo(int empNo, String deptNo);
	public DepartmentManager getDepartmentManagerByEmpNoAndFromDate(int empNo, LocalDate fromDate);

}
