package com.cg.training.services;

import java.time.LocalDate;
import java.util.List;

import com.cg.training.entities.Employee;
import com.cg.training.entities.Gender;

public interface EmployeeService {

	List<Employee> getEmployee();

	Employee getEmployeeById(int id);

	List<Employee> getEmployeeByFirstName(String firstName);

	List<Employee> getEmployeeByLastName(String lastName);

	List<Employee> getEmployeesByGender(Gender gender);

	List<Employee> getEmployeesByHireDate(LocalDate hireDate);

	List<Employee> getEmployeesByBirthDate(LocalDate birthDate);

	List<Employee> getAllEmployeesSortedByHireDateDesc();

	Employee addEmployee(Employee employee);

	Employee updateEmployee(Employee employee);

	Employee updateEmployeeLastName(Employee employee, int empNo);

	Employee updateEmployeeFirstName(Employee employee, int empNo);

	Employee updateEmployeeByHireDate(Employee employee, int empNo);

	Employee updateEmployeeBirthDate(Employee employee, int empNo);

}