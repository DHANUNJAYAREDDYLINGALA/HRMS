package com.cg.training.services;

import java.util.List;

import org.slf4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cg.training.dao.DepartmentsRepository;
import com.cg.training.entities.Departments;
import com.cg.training.loggers.GlobalLoggers;

/**
 * This class implements the DepartmentService interface and provides the business logic for managing departments.
 */
@Service
public class DepartmentServiceImpl implements DepartmentService {

	@Autowired
	private DepartmentsRepository departmentRepository;
	private Logger logger = GlobalLoggers.getLogger(DepartmentServiceImpl.class);
	
	/**
     * Retrieves all departments.
     *
     * @return A list of all departments.
     */
	public List<Departments> getDepartments() {
		String methodName = "Getdept()";
        logger.info(methodName + "called");
		return departmentRepository.findAll();
	}
	
	/**
     * Retrieves departments by department number.
     *
     * @param deptNo The department number.
     * @return A list of departments matching the given department number.
     */
	public List<Departments> getDepartmentsByDepNo(String deptNo) {
		String methodName = "Getbydeptno(deptNo)";
        logger.info(methodName + "called");
		if (deptNo != null)
			return departmentRepository.findByDeptNo(deptNo);
		else
			return null;
	}
	
	/**
     * Retrieves departments by department name.
     *
     * @param deptName The department name.
     * @return A list of departments matching the given department name.
     */
	public List<Departments> getDepartmentsByDeptName(String deptName) {
		String methodName = "Getbydeptname(deptName)";
        logger.info(methodName + "called");
		if (deptName != null)
			return departmentRepository.findByDeptName(deptName);
		else
			return null;
	}
	
	/**
     * Adds a new department.
     *
     * @param departments The department to be added.
     * @return The added department.
     */
	public Departments addDepartment(Departments departments) {
		String methodName = "Savedept(departments)";
        logger.info(methodName + "called");
		return departmentRepository.save(departments);
	}
	
	/**
     * Updates an existing department by department number.
     *
     * @param departments The department to be updated.
     * @return The updated department.
     */
	public Departments updateByDeptNo(Departments departments) {
		String methodName = "Updatebydeptno(departments)";
        logger.info(methodName + "called");
		return departmentRepository.save(departments);
	}
	
	/**
     * Updates an existing department by department name.
     *
     * @param departments The department to be updated.
     * @return The updated department.
     */
	public Departments updateByDeptName(Departments departments) {
		String methodName = "Updatebydeptname(departments)";
        logger.info(methodName + "called");
		return departmentRepository.save(departments);
	}
	
	/**
     * Deletes a department by department number.
     *
     * @param deptNo The department number.
     */
	@Transactional
	public void deleteByDeptNo(String deptNo) {
		String methodName = "Deletebydeptno(deptNo)";
        logger.info(methodName + "called");
		departmentRepository.deleteByDeptNo(deptNo);
	}
	
	/**
     * Deletes a department by department name.
     *
     * @param deptName The department name.
     */
	@Transactional
	public void deleteByDeptName(String deptName) {
		String methodName = "Deletebydeptname(deptName)";
        logger.info(methodName + "called");
		departmentRepository.deleteByDeptName(deptName);
	}


}
