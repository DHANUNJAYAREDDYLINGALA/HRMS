package com.cg.training.services;

import java.time.LocalDate;
import java.util.List;

import org.slf4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cg.training.dao.SalariesRepository;
import com.cg.training.entities.Salaries;
import com.cg.training.loggers.GlobalLoggers;

/**
 * This class provides the implementation for managing employee salaries.
 */
@Service
public class SalariesServiceImpl implements SalariesService {

 

    @Autowired
    private SalariesRepository salaryRepository;
    private Logger logger = GlobalLoggers.getLogger(SalariesServiceImpl.class);

    /**
     * Retrieves all salaries.
     *
     * @return A list of all salaries.
     */
    public List<Salaries> getSalary() {
    	String methodName = "Getsalary()";
        logger.info(methodName + "called");
        return salaryRepository.findAll();
    }

    /**
     * Retrieves salaries by from date.
     *
     * @param fromDate The from date.
     * @return A list of salaries matching the given from date.
     */
    public List<Salaries> getSalaryByFromDate(LocalDate fromDate) {
    	String methodName = "Getsalarybyfromdate(fromDate)";
        logger.info(methodName + "called");
    	
        return salaryRepository.findAllByFromDate(fromDate);
    }

 
    /**
     * Retrieves salaries by employee.
     *
     * @param empNo The employee number.
     * @return A list of salaries for the given employee.
     */
    public List<Salaries> getSalariesByEmployee(int empNo) {
    	String methodName = "Getsalarybyempl(empNo)";
        logger.info(methodName + "called");
        return salaryRepository.findSalaryByEmployee(empNo);
    }


    /**
     * Retrieves salaries within a salary range.
     *
     * @param minSalary The minimum salary.
     * @param maxSalary The maximum salary.
     * @return A list of salaries within the given range.
     */
    public List<Salaries> getSalaryByRange(int minSalary, int maxSalary) {
    	String methodName = "Getsalarybyrange(minSalary, maxSalary)";
        logger.info(methodName + "called");
        return salaryRepository.findAllBySalaryBetween(minSalary, maxSalary);
    }

    
    /**
     * Retrieves a salary by employee number and from date.
     *
     * @param empNo    The employee number.
     * @param fromDate The from date.
     * @return The salary matching the given employee number and from date.
     */
    public Salaries getSalaryByEmpNoandFromDate(int empNo, LocalDate fromDate) {
    	String methodName = "GetsalarybyempnoAndfromdate(LocalDate, fromDate)";
        logger.info(methodName + "called");
      return salaryRepository.findbyempnoandfromdate(empNo, fromDate);
  }

    /**
     * Adds a new salary.
     *
     * @param salary The salary to be added.
     * @return The added salary.
     */
    public Salaries addSalary(Salaries salary) {
    	String methodName = "Savesalary(salary)";
        logger.info(methodName + "called");
         return salaryRepository.save(salary);

    }
    
    /**
     * Updates an existing salary.
     *
     * @param salary The salary to be updated.
     * @return The updated salary.
     */
    
    public Salaries updateSalary(Salaries salary) {
    	String methodName = "Updatesalary(salary)";
        logger.info(methodName + "called");
        return salaryRepository.save(salary);
    }

    /**
     * Retrieves a salary by from dates.
     *
     * @param fromDate The from date.
     * @return The salary matching the given from date.
     */
    
    public Salaries getSalaryByFromDates(LocalDate fromDate) {
    	String methodName = "Getsalarybyfromdate(fromDate)";
        logger.info(methodName + "called");
        return salaryRepository.findbyfromdate(fromDate);
    }

 
    /**
     * Retrieves salaries by employee.
     *
     * @param empNo The employee number.
     * @return A list of salaries for the given employee.
     */
    public Salaries getSalariesByEmployees(int empNo) {
    	String methodName = "Getsalarybyempl(empNo)";
        logger.info(methodName + "called");
        return salaryRepository.findsSalaryByEmployee(empNo);
    }
    
    /**
     * Deletes a salary by employee number and from date.
     *
     * @param empNo    The employee number.
     * @param fromDate The from date.
     */
    @Transactional
    public void deleteByEmpNoAndFromDate(int empNo, LocalDate fromDate) {
    	String methodName = "DeletebyempnoAndfromdate(empNo, fromDate)";
        logger.info(methodName + "called");
        salaryRepository.deleteByEmployeeEmpNoAndFromDate(empNo, fromDate);
    }
    
    
    /**
     * Deletes salaries by from date.
     *
     * @param fromDate The from date.
     */
    @Transactional
    public void deleteByFromDate(LocalDate fromDate) {
    	String methodName = "Deletebyfromdate(fromDate)";
        logger.info(methodName + "called");
        salaryRepository.deleteByFromDate(fromDate);
    }
    
    /**
     * Deletes salaries by employee number.
     *
     * @param empNo The employee number.
     */
    @Transactional
    public void deleteByEmpNo(int empNo) {
    	String methodName = "Deletebyempno(empNo)";
        logger.info(methodName + "called");
        salaryRepository.deleteByEmployeeEmpNo(empNo);
    }

    
}
