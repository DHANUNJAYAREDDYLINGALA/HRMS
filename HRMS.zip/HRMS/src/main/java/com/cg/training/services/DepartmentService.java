package com.cg.training.services;

import java.util.List;
import com.cg.training.entities.Departments;

public interface DepartmentService {
	public List<Departments> getDepartments();
	public List<Departments> getDepartmentsByDepNo(String deptNo);
	public List<Departments> getDepartmentsByDeptName(String deptName);
	public Departments addDepartment(Departments departments);
	public Departments updateByDeptNo(Departments departments);
	public Departments updateByDeptName(Departments departments);
	public void deleteByDeptNo(String deptNo);
	public void deleteByDeptName(String deptName);
}