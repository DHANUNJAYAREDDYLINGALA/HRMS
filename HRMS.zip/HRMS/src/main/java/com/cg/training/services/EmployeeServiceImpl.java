package com.cg.training.services;

import java.time.LocalDate;
import java.util.List;

import org.slf4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.training.dao.EmployeeRepository;
import com.cg.training.entities.Employee;
import com.cg.training.entities.Gender;
import com.cg.training.loggers.GlobalLoggers;

/**
 * This class implements the EmployeeService interface and provides the business logic for managing employees.
 */
@Service
public class EmployeeServiceImpl implements EmployeeService {
    @Autowired
    private EmployeeRepository employeeRepository;
    private Logger logger = GlobalLoggers.getLogger(EmployeeServiceImpl.class);
    
    /**
     * Retrieves all employees.
     *
     * @return A list of all employees.
     */
    public List<Employee> getEmployee() {
    	String methodName = "Getempl()";
        logger.info(methodName + "called");
        return employeeRepository.findAll();
    }
    
    /**
     * Retrieves an employee by ID.
     *
     * @param id The ID of the employee.
     * @return The employee matching the given ID, or null if not found.
     */
    public Employee getEmployeeById(int id) {
    	String methodName = "Getemplbyid(id)";
        logger.info(methodName + "called");
        return employeeRepository.findById(id).orElse(null);
    }
    
    /**
     * Retrieves employees by first name.
     *
     * @param firstName The first name of the employee.
     * @return A list of employees matching the given first name.
     */
    public List<Employee> getEmployeeByFirstName(String firstName) {
    	String methodName = "Getemplbyfirstname(firstName)";
        logger.info(methodName + "called");
        return employeeRepository.findByFirstNameContains(firstName);
    }
    
    /**
     * Retrieves employees by last name.
     *
     * @param lastName The last name of the employee.
     * @return A list of employees matching the given last name.
     */
    public List<Employee> getEmployeeByLastName(String lastName) {
    	String methodName = "Getemplbylastname(lastName)";
        logger.info(methodName + "called");
        return employeeRepository.findByLastNameContains(lastName);
    }
    
    /**
     * Retrieves employees by gender.
     *
     * @param gender The gender of the employee.
     * @return A list of employees matching the given gender.
     */
    public List<Employee> getEmployeesByGender(Gender gender) {
    	String methodName = "Getemplbygender(gender)";
        logger.info(methodName + "called");
        try {
            List<Employee> records = employeeRepository.findByGenderContains(gender);
            System.out.println(records);
            return records;
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
            return null;
        }
    }
    
    /**
     * Retrieves employees by hire date.
     *
     * @param hireDate The hire date of the employee.
     * @return A list of employees matching the given hire date.
     */
    public List<Employee> getEmployeesByHireDate(LocalDate hireDate) {
    	String methodName = "Getemplbyhiredate(hireDate)";
        logger.info(methodName + "called");
        return employeeRepository.findByHireDate(hireDate);
    }
    
    /**
     * Retrieves employees by birth date.
     *
     * @param birthDate The birth date of the employee.
     * @return A list of employees matching the given birth date.
     */
    public List<Employee> getEmployeesByBirthDate(LocalDate birthDate) {
    	String methodName = "Getemplbybirthdate(birthDate)";
        logger.info(methodName + "called");
        return employeeRepository.findByBirthDate(birthDate);
    }
    
    /**
     * Retrieves all employees sorted by hire date in descending order.
     *
     * @return A list of all employees sorted by hire date in descending order.
     */
    public List<Employee> getAllEmployeesSortedByHireDateDesc() {
    	String methodName = "Getempl_sortedbyhiredatedesc()";
        logger.info(methodName + "called");
        return employeeRepository.findAllByOrderByHireDateDesc();
    }
// Post
    
    /**
     * Adds a new employee.
     *
     * @param employee The employee to be added.
     * @return The added employee.
     */
    public Employee addEmployee(Employee employee) {
    	String methodName = "Saveempl(employee)";
        logger.info(methodName + "called");
        Employee newEmployee = employeeRepository.save(employee);
        return newEmployee;
    }
    
    /**
     * Updates an existing employee.
     *
     * @param employee The employee to be updated.
     * @return The updated employee.
     */
    public Employee updateEmployee(Employee employee) {
    	String methodName = "Updateempl(employee)";
        logger.info(methodName + "called");
        Employee readEmployee = employeeRepository.findById(employee.getEmpNo()).orElse(null);
        readEmployee.setFirstName(employee.getFirstName());
        readEmployee.setLastName(employee.getLastName());
        readEmployee.setBirthDate(employee.getBirthDate());
        readEmployee.setHireDate(employee.getHireDate());
        return employeeRepository.save(readEmployee);
    }
    
    /**
     * Updates the last name of an existing employee.
     *
     * @param employee The employee to be updated.
     * @param empNo    The employee number.
     * @return The updated employee.
     */
    public Employee updateEmployeeLastName(Employee employee, int empNo) {
    	String methodName = "Updateempllastname(employee, empNo)";
        logger.info(methodName + "called");
        Employee readEmployee = employeeRepository.findById(empNo).orElse(null);
        if (readEmployee != null) {
            readEmployee.setLastName(employee.getLastName());
            return employeeRepository.save(readEmployee);
        }
        return null;
    }
    
    /**
     * Updates the first name of an existing employee.
     *
     * @param employee The employee to be updated.
     * @param empNo    The employee number.
     * @return The updated employee.
     */
    public Employee updateEmployeeFirstName(Employee employee, int empNo) {
    	String methodName = "Updateemplfirstname(employee, empNo)";
        logger.info(methodName + "called");
        Employee readEmployee = employeeRepository.findById(empNo).orElse(null);
        if (readEmployee != null) {
            readEmployee.setFirstName(employee.getFirstName());
            return employeeRepository.save(readEmployee);
        }
        return null;
    }
    
    /**
     * Updates the hire date of an existing employee.
     *
     * @param employee The employee to be updated.
     * @param empNo    The employee number.
     * @return The updated employee.
     */
    public Employee updateEmployeeByHireDate(Employee employee, int empNo) {
    	String methodName = "Updateemplhiredate(employee, empNo)";
        logger.info(methodName + "called");
        Employee readEmployee = employeeRepository.findById(empNo).orElse(null);
        readEmployee.setHireDate(employee.getHireDate());
        return employeeRepository.save(readEmployee);
    }

    /**
     * Updates the birth date of an existing employee.
     *
     * @param employee The employee to be updated.
     * @param empNo    The employee number.
     * @return The updated employee.
     */
    public Employee updateEmployeeBirthDate(Employee employee, int empNo) {
    	String methodName = "Updateemplbirthdate(employee, empNo)";
        logger.info(methodName + "called");
        Employee readEmployee = employeeRepository.findById(empNo).orElse(null);
        readEmployee.setBirthDate(employee.getBirthDate());
        return employeeRepository.save(readEmployee);
    }
}