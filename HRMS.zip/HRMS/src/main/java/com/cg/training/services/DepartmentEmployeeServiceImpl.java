package com.cg.training.services;

import java.time.LocalDate;
import java.util.List;

import org.slf4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cg.training.dao.DepartmentEmployeeRepository;
import com.cg.training.entities.DepartmentEmployee;
import com.cg.training.loggers.GlobalLoggers;

/**
 * This class implements the DepartmentEmployeeService interface and provides the business logic for managing department employees.
 */
@Service
public class DepartmentEmployeeServiceImpl implements DepartmentEmployeeService {
	
	@Autowired
	private  DepartmentEmployeeRepository departmentEmployeeRepository;
	private Logger logger = GlobalLoggers.getLogger(DepartmentEmployeeServiceImpl.class);
	
	/**
     * Retrieves all department employees.
     *
     * @return A list of department employees.
     */
	public List<DepartmentEmployee> getdepartmentemployee() {
		String methodName = "Getdeptemp()";
        logger.info(methodName + "called");
		return 	departmentEmployeeRepository.findAll();
	}
	
	/**
     * Retrieves department employees by department number and from date.
     *
     * @param deptNo   The department number.
     * @param fromDate The from date.
     * @return A list of department employees matching the given criteria.
     */
	 public List<DepartmentEmployee> findByDeptNoAndFromDate(String deptNo, LocalDate fromDate) {
		 String methodName = "GetbydeptdeptnoAndfromdate(deptNo, fromDate)";
	        logger.info(methodName + "called");
	        return departmentEmployeeRepository.findByDepartmentDeptNoAndFromDate(deptNo, fromDate);
	    }
	 
	 /**
	     * Retrieves a department employee by department number and from date.
	     *
	     * @param deptNo   The department number.
	     * @param fromDate The from date.
	     * @return The department employee matching the given criteria.
	     */
	 public DepartmentEmployee findBysDeptNoAndFromDate(String deptNo, LocalDate fromDate) {
		 String methodName = "Getbydept_deptnoAndfromdate(deptNo, fromDate)";
	        logger.info(methodName + "called");
	        return departmentEmployeeRepository.findByDepartment_DeptNoAndFromDate(deptNo, fromDate);
	    }
	    
	 /**
	     * Retrieves a department employee by employee number and from date.
	     *
	     * @param empNo    The employee number.
	     * @param fromDate The from date.
	     * @return The department employee matching the given criteria.
	     */
	    public DepartmentEmployee findByempNoAndFromDate(int empNo, LocalDate fromDate) {
	    	String methodName = "Getbyemp_empnoAndfromdate(empNo, fromDate)";
	        logger.info(methodName + "called");
	        return departmentEmployeeRepository.findByEmployee_EmpNoAndFromDate(empNo, fromDate);
	    }
	    
	    /**
	     * Retrieves a department employee by employee number and department number.
	     *
	     * @param empNo  The employee number.
	     * @param deptNo The department number.
	     * @return The department employee matching the given criteria.
	     */
	    public DepartmentEmployee getDepartEmployeeByEmpNoAndDeptNo(int empNo, String deptNo) {
	    	String methodName = "Getbyemp_empnoAnddeptno(empNo, deptNo)";
	        logger.info(methodName + "called");
	        return departmentEmployeeRepository.findByEmployee_EmpNoAndDepartment_DeptNo(empNo, deptNo);
	 }
	    
	    /**
	     * Retrieves a department employee by employee number, department number, and from date.
	     *
	     * @param empNo    The employee number.
	     * @param deptNo   The department number.
	     * @param fromDate The from date.
	     * @return The department employee matching the given criteria.
	     */
	    public DepartmentEmployee getDepartmentEmployeeByEmpNoAndDeptNoAndFromDate(int empNo, String deptNo, LocalDate fromDate) {
	    	String methodName = "Getbyemp_empnoAndDep_depnoAndfromdate(empNo,deptNo, fromDate)";
	        logger.info(methodName + "called");
	        return departmentEmployeeRepository.findByEmployee_EmpNoAndDepartment_DeptNoAndFromDate(empNo, deptNo, fromDate);
	    }
	    
	    /**
	     * Updates an existing department employee.
	     *
	     * @param departmentEmployee The department employee to be updated.
	     * @return The updated department employee.
	     */
	    public DepartmentEmployee updateDepartmentEmployee(DepartmentEmployee departmentEmployee) {
	    	String methodName = "Updatedeptemp(departmentEmployee)";
	        logger.info(methodName + "called");
	        return departmentEmployeeRepository.save(departmentEmployee);
	    }
	    
	    /**
	     * Saves a new department employee.
	     *
	     * @param departmentEmployee The department employee to be saved.
	     * @return The saved department employee.
	     */
	    public DepartmentEmployee saveDepartmentEmployee(DepartmentEmployee departmentEmployee) {
	    	String methodName = "Savedeptemp(departmentEmployee)";
	        logger.info(methodName + "called");
	        return departmentEmployeeRepository.save(departmentEmployee);
	    }
    
	    /**
	     * Deletes a department employee by employee number, department number, and from date.
	     *
	     * @param empNo    The employee number.
	     * @param fromDate The from date.
	     * @param deptNo   The department number.
	     */   	    
	    @Transactional
	    public void deleteByEmpNoAndDeptNoAndFromDate(int empNo, LocalDate fromDate, String deptNo) {
	    	String methodName = "DeletebyempnoAnddeptnoAndfromdate(empno,deptNo, fromDate)";
	        logger.info(methodName + "called");
	    	departmentEmployeeRepository.deleteByEmpNoAndDeptNoAndFromDate(empNo, deptNo, fromDate);
	    }

	    /**
	     * Deletes department employees by employee number and department number.
	     *
	     * @param empNo  The employee number.
	     * @param deptNo The department number.
	     */
	    @Transactional
	    public void deleteByEmpNoAndDeptNo(int empNo, String deptNo) {
	    	String methodName = "DeletebyempnoAnddeptno(deptNo, empNo)";
	        logger.info(methodName + "called");
	    	departmentEmployeeRepository.deleteByEmpNoAndDeptNo(empNo, deptNo);
	    }

	    /**
	     * Deletes department employees by employee number and from date.
	     *
	     * @param empNo    The employee number.
	     * @param fromDate The from date.
	     */
	    @Transactional
	    public void deleteByEmpNoAndFromDate(int empNo, LocalDate fromDate) {
	    	String methodName = "DeletebyempnoAndfromdate(deptNo, fromDate)";
	        logger.info(methodName + "called");
	    	departmentEmployeeRepository.deleteByEmpNoAndFromDate(empNo, fromDate);
	    }

	    /**
	     * Deletes department employees by department number and from date.
	     *
	     * @param deptNo   The department number.
	     * @param fromDate The from date.
	     */
	    @Transactional
	    public void deleteByDeptNoAndFromDate(String deptNo, LocalDate fromDate) {
	    	String methodName = "DeletebydeptnoAndfromdate(deptNo, fromDate)";
	        logger.info(methodName + "called");
	    	departmentEmployeeRepository.deleteByDeptNoAndFromDate(deptNo, fromDate);
	    }	 
}
