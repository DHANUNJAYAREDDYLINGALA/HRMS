package com.cg.training.services;

import java.time.LocalDate;
import java.util.List;

import org.slf4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cg.training.dao.TitlesRepository;
import com.cg.training.entities.Titles;
import com.cg.training.loggers.GlobalLoggers;

/**
 * This class provides the implementation for managing employee titles.
 */
@Service
public class TitleServiceImpl implements TitleService {
	
	@Autowired
    private TitlesRepository titlesRepository;
	private Logger logger = GlobalLoggers.getLogger(TitleServiceImpl.class);


 
	/**
     * Retrieves all titles.
     *
     * @return A list of all titles.
     */
    public List<Titles> getTitles() {
    	String methodName = "Gettitles()";
        logger.info(methodName + "called");
        return titlesRepository.findAll();
    }

    /**
     * Adds a new title.
     *
     * @param title The title to be added.
     * @return The added title.
     */
    public Titles addTitle(Titles title) {
    	String methodName = "Savetitles(titles)";
        logger.info(methodName + "called");
        return titlesRepository.save(title);
    }

    /**
     * Retrieves titles by employee number, from date, and title.
     *
     * @param empNo    The employee number.
     * @param fromDate The from date.
     * @param title    The title.
     * @return A list of titles matching the given employee number, from date, and title.
     */
    public List<Titles> getTitleByEmpNoAndDeptNo(int empNo, LocalDate fromDate, String title) {
    	String methodName = "GettitlesbyempnoAnddeptno(empno, fromDate, tittle)";
        logger.info(methodName + "called");
        return titlesRepository.findByTypeId(empNo, fromDate, title);
    }
 
    /**
     * Retrieves all titles with a specific title name.
     *
     * @param title The title name.
     * @return A list of titles with the given title name.
     */
    public List<Titles> getAllByTitle(String title) {
    	String methodName = "Gettitle(tittle)";
        logger.info(methodName + "called");
        return titlesRepository.findByTitles(title);
    }
 
    /**
     * Retrieves titles by from date.
     *
     * @param fromDate The from date.
     * @return A list of titles with the given from date.
     */
    public List<Titles> findAllByFromDate(LocalDate fromDate) {
    	String methodName = "Gettitlesbyfromdate(fromDate)";
        logger.info(methodName + "called");
        return titlesRepository.findByFromDate(fromDate);
    }

 
    /**
     * Retrieves titles by title name and from date.
     *
     * @param fromDate The from date.
     * @param title    The title name.
     * @return A list of titles with the given title name and from date.
     */
    public List<Titles> getTitleByTitleAndFromDate(LocalDate fromDate, String title) {
    	String methodName = "GettitlesbytitleAndfromdate(fromDate, tittle)";
    logger.info(methodName + "called");
        return titlesRepository.findByFromDateAndTitle(fromDate, title);
    }

 
    /**
     * Retrieves titles by employee number and title name.
     *
     * @param empNo The employee number.
     * @param title The title name.
     * @return A list of titles matching the given employee number and title name.
     */
    public List<Titles> getTitleByTitleAndFromDate(int empNo, String title) {
    	String methodName = "GettitlesbytitleAndfromdate(empno, tittle)";
        logger.info(methodName + "called");
        return titlesRepository.findByEmpnoAndTitle(empNo, title);
    }

    /**
     * Retrieves titles by employee number and from date.
     *
     * @param empNo    The employee number.
     * @param fromDate The from date.
     * @return A list of titles matching the given employee number and from date.
     */ 
    public List<Titles> getTitleByEmpNoAndFromDate(int empNo, LocalDate fromDate) {
    	String methodName = "GettitlesbyempnoAndfromdate(empno, fromDate)";
        logger.info(methodName + "called");
        return titlesRepository.findByFromDateAnDempNo(empNo, fromDate);
    }

    /**
     * Retrieves a title by employee number, from date, and title name.
     *
     * @param empNo    The employee number.
     * @param fromDate The from date.
     * @param title    The title name.
     * @return The title matching the given employee number, from date, and title name.
     */
	public Titles findByEmpNoAndFromDateAndTitle(int empNo, LocalDate fromDate, String title) {
		String methodName = "GetbyempnoAndfromdateAndtitle(empno, fromDate, tittle)";
        logger.info(methodName + "called");
        return titlesRepository.findByEmployee_EmpNoAndFromDateAndTitle(empNo, fromDate, title);
    }
	 
	/**
     * Retrieves the title by employee number.
     *
     * @param empNo The employee number.
     * @return The title for the given employee number.
     */
	public Titles getByEmpNo(int empNo) {
		String methodName = "Getbyempno(empno)";
        logger.info(methodName + "called");
		return titlesRepository.findByEmployee_EmpNo(empNo);
	}
	
	/**
     * Retrieves the title by from date.
     *
     * @param fromDate The from date.
     * @return The title with the given from date.
     */
	
	public Titles findByFromDates(LocalDate fromDate) {
		String methodName = "Getbyfromdate(fromDate)";
        logger.info(methodName + "called");
		return titlesRepository.findByFromDate1(fromDate);
	}
	
	
	/**
     * Retrieves the title by title name.
     *
     * @param title The title name.
     * @return The title with the given title name.
     */
	public Titles getbytitle(String title) {
		String methodName = "Getbytitle(tittle)";
        logger.info(methodName + "called");
		return titlesRepository.findByTitle(title);
	}
	
	/**
     * Updates the title by employee number.
     *
     * @param titles The title to be updated.
     * @return The updated title.
     */
	public Titles updateByEmpNo(Titles titles) {
		String methodName = "Updatebyempno(tittle)";
        logger.info(methodName + "called");
	    return titlesRepository.save(titles);
	}

	/**
     * Deletes the title by employee number, from date, and title name.
     *
     * @param empNo    The employee number.
     * @param fromDate The from date.
     * @param title    The title name.
     */
	@Transactional
	 public void deleteByEmpNoFromDateAndTitle(int empNo, LocalDate fromDate, String title) {
		String methodName = "DeletebyempnoAndfromdateAndtitle(empNo, fromDate, title)";
        logger.info(methodName + "called");
	        titlesRepository.deleteByEmployee_EmpNoAndFromDateAndTitle(empNo, fromDate, title);
	    }
	
	/**
     * Deletes the title by employee number.
     *
     * @param empNo The employee number.
     */
	@Transactional
	 public void deleteByEmpNo(int empNo) {
		String methodName = "Deletebyempno(empNo)";
        logger.info(methodName + "called");
		
	        titlesRepository.deleteByEmployee_EmpNo(empNo);
	    }
	
	/**
	 * Deletes titles by from date.
	 *
	 * @param fromDate The from date.
	 */
	@Transactional
	 public void deleteByFromDate(LocalDate fromDate) {
		String methodName = "Deletebyfromdate(fromDate)";
        logger.info(methodName + "called");
	        titlesRepository.deleteByFromDate(fromDate);
	    }
	
	/**
	 * Deletes titles by title name.
	 *
	 * @param title The title name.
	 */
	@Transactional
	 public void deleteByTitle(String title) {
		String methodName = "Deletebytitle(title)";
        logger.info(methodName + "called");
	        titlesRepository.deletebyTitle(title);
	    }
	
}
