package com.cg.training.controller;

import java.time.LocalDate;
import java.util.List;

import org.slf4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cg.training.entities.Employee;
import com.cg.training.entities.Gender;
import com.cg.training.exceptions.InvalidDataException;
import com.cg.training.exceptions.NotFoundException;
import com.cg.training.loggers.GlobalLoggers;
import com.cg.training.services.EmployeeServiceImpl;

import io.swagger.v3.oas.annotations.Operation;

//It contains various endpoints for managing employee data.
@RestController
@RequestMapping("/api/v1/employees")
public class EmployeeController {

	@Autowired
	public EmployeeServiceImpl employeeService;
	private Logger logger = GlobalLoggers.getLogger(EmployeeController.class);

	/*
     * Fetch all employees.
     */
	@GetMapping("/all")
	@Operation(summary = "Fetch all employees.")
	public List<Employee> findAllEmployees() {
		String methodName = "GetAllemployees()";
		logger.info(methodName + "called");
		return employeeService.getEmployee();
	}

	/*
     *  Fetch an employee by employee number.
     *  If the employee exists, returns the Employee object.
	 *If the employee doesn't exist, throws a NotFoundException with HTTP status 404 (Not Found).
     */
	@GetMapping("/{id}")
	@Operation(summary = "Fetch an employees by employee number")
	public Employee findEmployeeById(@PathVariable int id) { // Change
		String methodName = "GetEmployeesById(id)";
		logger.info(methodName + "called");
		if (employeeService.getEmployeeById(id) != null)
			return employeeService.getEmployeeById(id);
		else
			throw new NotFoundException("Employee Id is not correct! Please check again");
	}

	/*
     * Search employees by first name.
     * If employees with the given first name exist, returns a list of Employee objects.
	 *If no employees are found, throws a NotFoundException with HTTP status 404 (Not Found).
     */
	@GetMapping("/firstname/{firstName}")
	@Operation(summary = "Search Employee by First Name")
	public List<Employee> findEmployeeByFirstName(@PathVariable("firstName") String firstName) {
		String methodName = "GetEmployeesByFirstName(firstName)";
		logger.info(methodName + "called");
		if (employeeService.getEmployeeByFirstName(firstName) != null)
			return employeeService.getEmployeeByFirstName(firstName);
		else
			throw new NotFoundException("First Name is not correct! Please Check again.");
	}

	/*
     * Search employees by last name.
     */
	@GetMapping("/lastname/{lastName}")
	@Operation(summary = "Search Employee by Last Name")
	public List<Employee> findEmployeeByLastName(@PathVariable("lastName") String lastName) {
		String methodName = "GetEmployeesByLastName(lastName)";
		logger.info(methodName + "called");
		return employeeService.getEmployeeByLastName(lastName);
	}

	/*
     * Search employees by gender.
     */
	@GetMapping("/gender/{gender}")
	@Operation(summary = "Search employees by gender")
	public List<Employee> findByGender(@PathVariable("gender") String gender) {
		String methodName = "GetEmployeesByGender(gender)";
		logger.info(methodName + "called");
		Gender g = Gender.valueOf(gender);
		return employeeService.getEmployeesByGender(g);
	}

	/*
     * Search employees by hire date.
     */
	@GetMapping("/hiredate/{hiredate}")
	@Operation(summary = "Search employees by  hire date")
	public List<Employee> findEmployeesByHireDate(
			@PathVariable("hiredate") @DateTimeFormat(pattern = "yyyy-MM-dd") LocalDate hireDate) {
		String methodName = "GetEmployeesByhireDate(hireDate)";
		logger.info(methodName + "called");
		return employeeService.getEmployeesByHireDate(hireDate);
	}

	/*
     * Search employees by birth date.
     */
	@GetMapping("/birthdate/{birthdate}")
	@Operation(summary = "Search employees by  birth date")
	public List<Employee> findEmployeesByBirthDate(
			@PathVariable("birthdate") @DateTimeFormat(pattern = "yyyy-MM-dd") LocalDate birthDate) {
		String methodName = "GetEmployeesByDOB(birthDate)";
		logger.info(methodName + "called");
		return employeeService.getEmployeesByBirthDate(birthDate);
	}
	
	/*
     *Add a new employee to the database. 
     *If the employee is successfully added, returns a success message with HTTP status 200 (OK).
	 *If the validation fails, throws an InvalidDataException with HTTP status 400 (Bad Request).
     */
	@PostMapping("/add")
	@Operation(summary = "Add new employee object in DB")
	public ResponseEntity<String> addEmployeeC(@RequestBody Employee employee) {
		String methodName = "AddnewEmployees()";
		logger.info(methodName + "called");
		Employee response = employeeService.addEmployee(employee);
		if (response != null)
			return new ResponseEntity<String>("New employee added successfully", HttpStatus.OK);
		else
			throw new InvalidDataException("Validation Failed: Invalid entry.Please Check again");
	}

	/*
     * Update the last name of an employee by employee number.
     * If the employee exists and the last name is updated, returns the updated Employee object with HTTP status 200 (OK).
	 *If the employee doesn't exist, throws a NotFoundException with HTTP status 404 (Not Found).
     */
	@PutMapping("/lastname/{empno}")
	@Operation(summary = "Update Last Name of an employee given empno")
	public ResponseEntity<Employee> updateEmployeeByLastNameC(@PathVariable("empno") int empNo,
			@RequestBody Employee employee) {
		String methodName = "UpdateLastNameOfEmployeesById(employee,empNo)";
		logger.info(methodName + "called");
		Employee emp = employeeService.updateEmployeeLastName(employee, empNo);

		if (emp != null)
			return new ResponseEntity<Employee>(emp, HttpStatus.OK);
		else
			throw new NotFoundException("Invalid Id: Unable to update the lastname");
	}

	/*
     *Update the first name of an employee by employee number.
     *If the employee exists and the first name is updated, returns the updated Employee object with HTTP status 200 (OK).
	 *If the employee doesn't exist, throws a NotFoundException with HTTP status 404 (Not Found). 
     */
	@PutMapping("/firstname/{empno}")
	@Operation(summary = "Update first Name of an employee given empno")
	public ResponseEntity<Employee> updateEmployeeByFirstNameC(@PathVariable("empno") int empNo,
			@RequestBody Employee employee) {
		String methodName = "UpdatefirstNameofEmployeesById(employee,empNo)";
		logger.info(methodName + "called");
		Employee emp = employeeService.updateEmployeeFirstName(employee, empNo);
		if (emp != null)
			return new ResponseEntity<Employee>(emp, HttpStatus.OK);
		else
			throw new NotFoundException("Invalid Id: Unable to update the firstname");
	}

	/*
     * Update the hire date of an employee by employee number.
     */
	@PutMapping("/hiredate/{empno}")
	@Operation(summary = "Update hiredate for given empno")
	public Employee updateEmployeeByHireDateC(@PathVariable("empno") int empNo, @RequestBody Employee employee) {
		String methodName = "UpdateEmployeeshireDateById(employee,id)";
		logger.info(methodName + "called");
		return employeeService.updateEmployeeByHireDate(employee, empNo);
	}

	/*
     * Update the birth date of an employee by employee number.
     */
	@PutMapping("/birthdate/{empno}")
	@Operation(summary = "Update birthdate for given empno")
	public Employee updateEmployeeByBirthDateC(@PathVariable("empno") int empNo, @RequestBody Employee employee) {
		String methodName = "UpdateDOBofEmployeesById(employee,id)";
		logger.info(methodName + "called");
		return employeeService.updateEmployeeBirthDate(employee, empNo);
	}

}