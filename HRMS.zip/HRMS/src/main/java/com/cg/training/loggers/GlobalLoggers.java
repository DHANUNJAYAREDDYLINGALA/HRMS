package com.cg.training.loggers;

import org.slf4j.LoggerFactory;
import org.slf4j.Logger;

public class GlobalLoggers {
	public static Logger getLogger(Class className) {
	    return LoggerFactory.getLogger(className);
	}
}
