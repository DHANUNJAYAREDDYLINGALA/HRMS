package com.cg.training.services;

import java.time.LocalDate;
import java.util.List;

import org.springframework.transaction.annotation.Transactional;

import com.cg.training.entities.Titles;

public interface TitleService {

	List<Titles> getTitles();

	Titles addTitle(Titles title);

	List<Titles> getTitleByEmpNoAndDeptNo(int empNo, LocalDate fromDate, String title);

	List<Titles> getAllByTitle(String title);

	List<Titles> findAllByFromDate(LocalDate fromDate);

	List<Titles> getTitleByTitleAndFromDate(LocalDate fromDate, String title);

	List<Titles> getTitleByTitleAndFromDate(int empNo, String title);

	List<Titles> getTitleByEmpNoAndFromDate(int empNo, LocalDate fromDate);

	Titles findByEmpNoAndFromDateAndTitle(int empNo, LocalDate fromDate, String title);

	Titles getByEmpNo(int empNo);

	Titles findByFromDates(LocalDate fromDate);

	Titles getbytitle(String title);

	Titles updateByEmpNo(Titles titles);

	void deleteByEmpNoFromDateAndTitle(int empNo, LocalDate fromDate, String title);

	void deleteByEmpNo(int empNo);

	void deleteByFromDate(LocalDate fromDate);

	void deleteByTitle(String title);

}