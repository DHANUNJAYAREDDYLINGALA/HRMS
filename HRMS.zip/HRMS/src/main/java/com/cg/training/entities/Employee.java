package com.cg.training.entities;

import java.time.LocalDate;
import java.util.Date;
import java.util.List;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.FetchType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;



@Entity
@Table(name = "employees")

public class Employee {
	
	@Id
	@Column(name = "emp_no", nullable=false)
	private int empNo;
	
	@Column(name = "birth_date", nullable=false)
	private LocalDate birthDate;
	
	@Column(name = "first_name", nullable=false, length=14)
	private String firstName;
	
	@Column(name = "last_name", nullable=false, length=16)
	private String lastName;

	@Enumerated(EnumType.STRING)
	@Column(name = "gender", nullable=false)
	private Gender gender;

	@Column(name = "hire_date", nullable=false)
	private LocalDate hireDate;

	@OneToMany(mappedBy = "employee", cascade = CascadeType.ALL, fetch=FetchType.EAGER)
	private List<DepartmentManager> departmentManager;


    @OneToMany(mappedBy = "employee", cascade = CascadeType.ALL, fetch = FetchType.EAGER)
    private List<DepartmentEmployee> departmentEmployee;
	
	@OneToMany(mappedBy = "employee", cascade = CascadeType.ALL,fetch=FetchType.EAGER)
	private List<Salaries> salary;
	
	@OneToMany(mappedBy = "employee", cascade = CascadeType.ALL,fetch=FetchType.EAGER)
	private List<Titles> titles;

	public Employee(int empNo, LocalDate birthDate, String firstName, String lastName, Gender gender, LocalDate hireDate) {
		super();
		this.empNo = empNo;
		this.birthDate = birthDate;
		this.firstName = firstName;
		this.lastName = lastName;
		this.gender = gender;
		this.hireDate = hireDate;
	}

	public Employee() {
		super();
	}

	public int getEmpNo() {
		return empNo;
	}

	public void setEmpNo(int empNo) {
		this.empNo = empNo;
	}

	public LocalDate getBirthDate() {
		return birthDate;
	}

	public void setBirthDate(LocalDate birthDate) {
		this.birthDate = birthDate;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public Gender getGender() {
		return gender;
	}

	public void setGender(Gender gender) {
		this.gender = gender;
	}

	public LocalDate getHireDate() {
		return hireDate;
	}

	public void setHireDate(LocalDate hireDate) {
		this.hireDate = hireDate;
	}
	
	
}
