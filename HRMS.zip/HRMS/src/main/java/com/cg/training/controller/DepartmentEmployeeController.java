package com.cg.training.controller;

import java.time.LocalDate;
import java.util.List;

import org.slf4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cg.training.entities.DepartmentEmployee;
import com.cg.training.exceptions.InvalidDataException;
import com.cg.training.loggers.GlobalLoggers;
import com.cg.training.services.DepartmentEmployeeServiceImpl;

import io.swagger.v3.oas.annotations.Operation;

/*
 *  It contains various CRUD (Create, Read, Update, Delete) operations for managing department employees.
 */

@RestController
@RequestMapping("/api/v1/deptemp")
public class DepartmentEmployeeController {
	
	@Autowired
	private DepartmentEmployeeServiceImpl departmentEmployeeServices;
	private Logger logger = GlobalLoggers.getLogger(DepartmentEmployeeController.class);
	
	//Retrieve a list of all department employees.
	@GetMapping("get/")
	public List<DepartmentEmployee> findAlldepartmentsemployee() {
		String methodName = "getAll";
        logger.info(methodName + "called");
		return departmentEmployeeServices.getdepartmentemployee();
		
	}
	
	//Retrieve a department employee by employee number and department number.
	 @GetMapping("/empno/{empNo}/deptno/{deptNo}")
	    public DepartmentEmployee findByEmpNoAndDeptNo(
	            @PathVariable("empNo") int empNo,
	            @PathVariable("deptNo") String deptNo
	    ) {
		 String methodName = "findByempIdAnddeptNo(empNo,deptNo)";
	        logger.info(methodName + "called");
	        return departmentEmployeeServices.getDepartEmployeeByEmpNoAndDeptNo(empNo, deptNo);
	    }
	 
		// Retrieve department employees by department number and from date.
	 @GetMapping("/deptno/{deptNo}/fromdate/{fromDate}")
	    public List<DepartmentEmployee> findByDeptNoFromDate(
	            @PathVariable("deptNo") String deptNo,
	            @PathVariable("fromDate") @DateTimeFormat(pattern = "yyyy-MM-dd") LocalDate fromDate
	    ) {
		 String methodName = "GetDeptEmpbyDeptNoAndfromDate(deptno, fromDate)";
	        logger.info(methodName + "called");
	        List<DepartmentEmployee> departmentManagers = departmentEmployeeServices.findByDeptNoAndFromDate(deptNo, fromDate);
	        System.out.println(departmentManagers);
	        return departmentManagers;
	    }
		//Retrieve a department employee by employee number and from date.
		@GetMapping("/empno/{empNo}/fromdate/{fromDate}")
	    public DepartmentEmployee findByempNoFromDate(
	            @PathVariable("empNo") int empNo,
	            @PathVariable("fromDate") @DateTimeFormat(pattern = "yyyy-MM-dd") LocalDate fromDate
	    ) {
			String methodName = "GetDeptEmpbyEmpNoAndfromDate(id, name)";
	        logger.info(methodName + "called");
	        DepartmentEmployee departmentManagers = departmentEmployeeServices.findByempNoAndFromDate(empNo, fromDate);
	        System.out.println(departmentManagers);
	        return departmentManagers;
	    }
		
		//Retrieve a department employee by employee number, department number, and from date.
		@GetMapping("/empno/{empNo}/deptno/{deptNo}/fromdate/{fromDate}")
		public DepartmentEmployee findbyempnodeptnoAndfromdate(@PathVariable("empNo") int empNo, @PathVariable("deptNo") String deptNo, @PathVariable("fromDate") @DateTimeFormat(pattern = "yyyy-MM-dd") LocalDate fromDate) {
			String methodName = "GetDeptEmpbyEmpNoDeptNoAndfromDate(empNo,deptNo,fromDate,)";
	        logger.info(methodName + "called");
			return departmentEmployeeServices.getDepartmentEmployeeByEmpNoAndDeptNoAndFromDate(empNo, deptNo, fromDate);
		}

		/*Add a new department employee to the database.
		 *If the department employee is successfully created, returns the created DepartmentEmployee object with HTTP status 200 (OK).
		 *If the validation fails, throws an InvalidDataException with HTTP status 400 (Bad Request).
		 */
	    @PostMapping("/add")
	    @Operation(summary = "Add new saveDepartmentEmployee object in DB")
	    public ResponseEntity<DepartmentEmployee> addNewdepartmentemployee(@RequestBody DepartmentEmployee departmentEmployee) {
	    	String methodName = "UpdateDeptEmp()";
	        logger.info(methodName + "called");
	    	DepartmentEmployee createdTitle = departmentEmployeeServices.saveDepartmentEmployee(departmentEmployee);
	        if (createdTitle != null) {
	            return ResponseEntity.status(HttpStatus.OK).body(createdTitle);
	        } else {
	            throw new InvalidDataException("Validation Failed");
	        }
	    }
		
	    /*Add a new department employee to the database.
		 *If the department employee is successfully created, returns the created DepartmentEmployee object with HTTP status 200 (OK).
		 *If the validation fails, throws an InvalidDataException with HTTP status 400 (Bad Request).
		 */
		@Transactional
		@PutMapping("/empNo/{empNo}/deptNo/{deptNo}/fromDate/{fromDate}")
		public ResponseEntity<DepartmentEmployee> updateDepartmentManager(	
		    @PathVariable int empNo,
		    @PathVariable String deptNo,
		    @PathVariable("fromDate") @DateTimeFormat(pattern = "yyyy-MM-dd") LocalDate fromDate,
		    @RequestBody DepartmentEmployee departmentEmployee) {
			String methodName = "UpdateDeptEmpbyempNoDeptNoAndfromDate(empNo,deptNo,fromDate)";
	        logger.info(methodName + "called");
		    DepartmentEmployee existingEmployee = departmentEmployeeServices.getDepartmentEmployeeByEmpNoAndDeptNoAndFromDate(empNo, deptNo, fromDate);
		    if (existingEmployee != null) {
		        existingEmployee.getEmployee().setFirstName(departmentEmployee.getEmployee().getFirstName());
		        existingEmployee.getEmployee().setLastName(departmentEmployee.getEmployee().getLastName());
		        existingEmployee.getEmployee().setBirthDate(departmentEmployee.getEmployee().getBirthDate());
		        existingEmployee.getEmployee().setGender(departmentEmployee.getEmployee().getGender());
		        existingEmployee.setFromDate(departmentEmployee.getFromDate());
		        existingEmployee.setToDate(departmentEmployee.getToDate());
		        
		        DepartmentEmployee updatedEmployee = departmentEmployeeServices.updateDepartmentEmployee(existingEmployee);

		        return ResponseEntity.ok(updatedEmployee);
		    } else {
		        return ResponseEntity.notFound().build();
		    }
		}
		
		/*
		 * Update a department employee by employee number and from date.
		 * If the department employee exists, updates the employee and returns the updated DepartmentEmployee object with HTTP status 200 (OK).
		 *If the department employee doesn't exist, returns HTTP status 404 (Not Found).
		 */
		@Transactional
		@PutMapping("/empNo/{empNo}/fromDate/{fromDate}")
		public ResponseEntity<DepartmentEmployee> updateDepartmentManager(
		    @PathVariable int empNo,
		    @PathVariable("fromDate") @DateTimeFormat(pattern = "yyyy-MM-dd") LocalDate fromDate,
		    @RequestBody DepartmentEmployee departmentEmployee) {
			String methodName = "UpdateDeptEmpByempNoAndfromDate(empNo, fromDate)";
	        logger.info(methodName + "called");
		    DepartmentEmployee existingEmployee = departmentEmployeeServices.findByempNoAndFromDate(empNo, fromDate);
		    if (existingEmployee != null) {
		        existingEmployee.getEmployee().setFirstName(departmentEmployee.getEmployee().getFirstName());
		        existingEmployee.getEmployee().setLastName(departmentEmployee.getEmployee().getLastName());
		        existingEmployee.getEmployee().setBirthDate(departmentEmployee.getEmployee().getBirthDate());

		        DepartmentEmployee updatedEmployee = departmentEmployeeServices.updateDepartmentEmployee(existingEmployee);

		        return ResponseEntity.ok(updatedEmployee);
		    } else {
		        return ResponseEntity.notFound().build();
		    }
		}
		
		/*
		 * Update a department employee by employee number and department number.
		
		 *If the department employee exists, updates the employee and returns the updated DepartmentEmployee object with HTTP status 200 (OK).
		 *If the department employee doesn't exist, returns HTTP status 404 (Not Found).
		 */
		@Transactional
		@PutMapping("/empNo/{empNo}/deptNo/{deptNo}")
		public ResponseEntity<DepartmentEmployee> updateDepartmentManager(
		    @PathVariable int empNo,
		    @PathVariable String deptNo,
		    @RequestBody DepartmentEmployee departmentEmployee) {
			String methodName = "UpdateDeptEmpByEmpNoAndDeptNo(empNo, deptNo)";
	        logger.info(methodName + "called");
		    
		    DepartmentEmployee existingEmployee = departmentEmployeeServices.getDepartEmployeeByEmpNoAndDeptNo(empNo, deptNo);
		    if (existingEmployee != null) {
		        existingEmployee.getEmployee().setFirstName(departmentEmployee.getEmployee().getFirstName());
		        existingEmployee.getEmployee().setLastName(departmentEmployee.getEmployee().getLastName());
		        existingEmployee.getEmployee().setBirthDate(departmentEmployee.getEmployee().getBirthDate());

		        
		        DepartmentEmployee updatedEmployee = departmentEmployeeServices.updateDepartmentEmployee(existingEmployee);

		        return ResponseEntity.ok(updatedEmployee);
		    } else {
		        return ResponseEntity.notFound().build();
		    }
		}
		
		/*
		 * Update a department employee by department number and from date.
		 *If the department employee exists, updates the employee and returns the updated DepartmentEmployee object with HTTP status 200 (OK).
		 *If the department employee doesn't exist, returns HTTP status 404 (Not Found).
		 */
		@Transactional
		@PutMapping("/deptNo/{deptNo}/fromDate/{fromDate}")
		public ResponseEntity<DepartmentEmployee> updateDepartmentManager(
		    @PathVariable String deptNo,
		    @PathVariable("fromDate") @DateTimeFormat(pattern = "yyyy-MM-dd") LocalDate fromDate,
		    @RequestBody DepartmentEmployee departmentEmployee) {
			String methodName = "UpdateDeptempByDeptNoAndfromDate(id, name)";
	        logger.info(methodName + "called");
		    
		    DepartmentEmployee existingEmployee = departmentEmployeeServices.findBysDeptNoAndFromDate(deptNo, fromDate);
		    if (existingEmployee != null) {
		        existingEmployee.getEmployee().setFirstName(departmentEmployee.getEmployee().getFirstName());
		        existingEmployee.getEmployee().setLastName(departmentEmployee.getEmployee().getLastName());
		        existingEmployee.getEmployee().setBirthDate(departmentEmployee.getEmployee().getBirthDate());
		        
		        DepartmentEmployee updatedEmployee = departmentEmployeeServices.updateDepartmentEmployee(existingEmployee);

		        return ResponseEntity.ok(updatedEmployee);
		    } else {
		        return ResponseEntity.notFound().build();
		    }
		}
		
		/*
		 * Delete a department employee by employee number, department number, and from date.
		 *Response: Returns HTTP status 204 (No Content) if the deletion is successful.
		 */
		@DeleteMapping("/empno/{empNo}/deptno/{deptNo}/fromdate/{fromDate}")
	    public ResponseEntity<Void> deleteDepartmentEmployeeByEmpNoAndDeptNoAndFromDate(
	            @PathVariable int empNo,
	            @PathVariable String deptNo,
	            @PathVariable @DateTimeFormat(pattern = "yyyy-MM-dd") LocalDate fromDate) {
			String methodName = "DeleteDeptEmpByEmpNoDeptNoAndfromDate(id, name)";
	        logger.info(methodName + "called");
			departmentEmployeeServices.deleteByEmpNoAndDeptNoAndFromDate(empNo, fromDate, deptNo);
	        return ResponseEntity.noContent().build();
	    }

		/*
		 *Delete a department employee by employee number and department number. 
		 *Returns HTTP status 204 (No Content) if the deletion is successful.
		 */
	    @DeleteMapping("/empno/{empNo}/deptno/{deptNo}")
	    public ResponseEntity<Void> deleteDepartmentEmployeeByEmpNoAndDeptNo(
	            @PathVariable int empNo,
	            @PathVariable String deptNo) {
	    	String methodName = "DeleteDeptEmpByEmpNoAndDeptNo(empNo, deptNo)";
	        logger.info(methodName + "called");
	    	departmentEmployeeServices.deleteByEmpNoAndDeptNo(empNo, deptNo);
	        return ResponseEntity.noContent().build();
	    }

	    /*
		 *  Delete a department employee by employee number and from date.
		 *  Returns HTTP status 204 (No Content) if the deletion is successful.
		 */
	    @DeleteMapping("/empno/{empNo}/fromdate/{fromDate}")
	    public ResponseEntity<Void> deleteDepartmentEmployeeByEmpNoAndFromDate(
	            @PathVariable int empNo,
	            @PathVariable @DateTimeFormat(pattern = "yyyy-MM-dd") LocalDate fromDate) {
	    	String methodName = "DeleteDeptEmpByempNoAndfromDate(empNo, fromDate)";
	        logger.info(methodName + "called");
	    	departmentEmployeeServices.deleteByEmpNoAndFromDate(empNo, fromDate);
	        return ResponseEntity.noContent().build();
	    }

	    /*
		 *  Delete department employees by department number and from date.
		 *Returns HTTP status 204 (No Content) if the deletion is successful.
		 */
	    @DeleteMapping("/deptno/{deptNo}/fromdate/{fromDate}")
	    public ResponseEntity<Void> deleteDepartmentEmployeeByDeptNoAndFromDate(
	            @PathVariable String deptNo,
	            @PathVariable @DateTimeFormat(pattern = "yyyy-MM-dd") LocalDate fromDate) {
	    	String methodName = "DeleteDeptEmpBydeptNoAndfromDate(deptNo, fromDate)";
	        logger.info(methodName + "called");
	    	departmentEmployeeServices.deleteByDeptNoAndFromDate(deptNo, fromDate);
	        return ResponseEntity.noContent().build();
	    }

		

}
