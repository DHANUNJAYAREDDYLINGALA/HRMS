package com.cg.training.controller;

import java.time.LocalDate;
import java.util.List;

import org.slf4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.cg.training.entities.Salaries;
import com.cg.training.exceptions.InvalidDataException;
import com.cg.training.loggers.GlobalLoggers;
import com.cg.training.services.SalariesServiceImpl;

import io.swagger.v3.oas.annotations.Operation;

//It contains various endpoints for managing salary data.
@RestController
@RequestMapping("/api/v1/salaries")
public class SalariesController {

    @Autowired
    public SalariesServiceImpl salaryService;
    private Logger logger = GlobalLoggers.getLogger(SalariesController.class);

    //Fetch all salary objects.
    @GetMapping("/all")
    @Operation(summary = "Fetch all salary objects")
    public List<Salaries> findAllSalary() {
    	String methodName = "GetAllSalaries()";
        logger.info(methodName + "called");
        return salaryService.getSalary();
    }

    //Fetch salary objects by from date.
    @GetMapping("/fromdate/{fromdate}")
    @Operation(summary = "Fetch all salary objects by from date")
    public List<Salaries> findSalaryByFromDate(
            @PathVariable("fromdate") @DateTimeFormat(pattern = "yyyy-MM-dd") LocalDate fromDate) {
    	String methodName = "GetSalariesByfromDate(fromDate)";
        logger.info(methodName + "called");
        return salaryService.getSalaryByFromDate(fromDate);
    }

 
    // Fetch salary objects by employee number.
    @GetMapping("/empno/{empno}")
    @Operation(summary = "Fetch all salary objects by empno")
    public List<Salaries> findSalaryByEmployee(@PathVariable("empno") int empNo) {
    	String methodName = "GetSalariesByempNo(fromDate)";
        logger.info(methodName + "called");
        return salaryService.getSalariesByEmployee(empNo);
    }

 
    //Fetch salary objects by salary range.
    @GetMapping("/salary/{minsalary}/{maxsalary}")
    @Operation(summary = "Fetch all salary objects by salary ")
    public List<Salaries> findSalaryByRange(@PathVariable("minsalary") int minSalary,
            @PathVariable("maxsalary") int maxSalary) {
    	String methodName = "GetSalariesByRange(minSalary,maxSalary)";
        logger.info(methodName + "called");
        return salaryService.getSalaryByRange(minSalary, maxSalary);
    }
    
  //Fetch salary object by employee number and from date.

    @GetMapping("/empNo/{empNo}/fromDate/{fromDate}")
    public Salaries findSalaryByFromDate(@PathVariable("empNo") int empNo, @PathVariable("fromDate") @DateTimeFormat(pattern = "yyyy-MM-dd") LocalDate fromDate) {
    	String methodName = "GetSalariesByEmpNoAndfromDate(empNo,fromDate)";
        logger.info(methodName + "called");
    	return salaryService.getSalaryByEmpNoandFromDate(empNo, fromDate);
    }

 
  //Add a new salary object to the database.
    /*
     * If the salary is successfully added, returns a success message with HTTP status 200 (OK).
	 *If the validation fails, throws an InvalidDataException with HTTP status 400 (Bad Request).
     */
    @PostMapping("/add")
    @Operation(summary = "Add new salary object in DB")
    public ResponseEntity<String> addSalaryC(@RequestBody Salaries salary) {
    	String methodName = "AddnewSalary(salary)";
        logger.info(methodName + "called");
        Salaries response = salaryService.addSalary(salary);
        if (response != null)
            return new ResponseEntity<String>("New Salary details added Successfully", HttpStatus.OK);
        else
            throw new InvalidDataException("Validation Failed: ");
    }

    /*Update salary by from date.
     * If the salary is successfully updated, returns the updated Salaries object with HTTP status 200 (OK).
	 *If the salary doesn't exist, returns HTTP status 500 (Internal Server Error).
     */
    @PutMapping("/fromdate/{fromDate}")
    public ResponseEntity<Salaries> updateSalaryByEmpNoAndFromDate(
            @RequestBody Salaries salary,
            @PathVariable("fromDate") @DateTimeFormat(pattern = "yyyy-MM-dd") LocalDate fromDate) {
    	String methodName = "UpdateSalariesByfromDate(fromDate)";
        logger.info(methodName + "called");
        Salaries existingSalary = salaryService.getSalaryByFromDates(fromDate);
        
        if (existingSalary != null) {
            existingSalary.setSalary(salary.getSalary());
            existingSalary.setToDate(salary.getToDate());
            Salaries updatedSalary = salaryService.updateSalary(existingSalary);
            return ResponseEntity.ok(updatedSalary);
        }
        
        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
    }
    
    /*
     *Update salary by employee number and from date.
     * If the salary is successfully updated, returns the updated Salaries object with HTTP status 200 (OK).
	 *If the salary doesn't exist, returns HTTP status 500 (Internal Server Error).
     */
    @PutMapping("/empno/{empNo}/fromdate/{fromDate}")
    public ResponseEntity<Salaries> updateSalaryByEmpNoAndFromDate(
            @RequestBody Salaries salary,
            @PathVariable int empNo,
            @PathVariable("fromDate") @DateTimeFormat(pattern = "yyyy-MM-dd") LocalDate fromDate) {
    	String methodName = "UpdateSalariesByempNoAndfromDate(empNo,fromDate)";
        logger.info(methodName + "called");
        Salaries existingSalary = salaryService.getSalaryByEmpNoandFromDate(empNo, fromDate);
        
        if (existingSalary != null) {
            existingSalary.setSalary(salary.getSalary());
            Salaries updatedSalary = salaryService.updateSalary(existingSalary);
            return ResponseEntity.ok(updatedSalary);
        }
        
        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
    }

    /*
     * Update salary by employee number.
     * If the salary is successfully updated, returns the updated Salaries object with HTTP status 200 (OK).
	 *If the salary doesn't exist, returns HTTP status 500 (Internal Server Error).
     */
    @PutMapping("/empno/{empNo}")
    public ResponseEntity<Salaries> updateSalaryByEmpNoAndFromDate(
            @RequestBody Salaries salary,
            @PathVariable int empNo) {
    	String methodName = "UpdateSalariesByempNo(empNo)";
        logger.info(methodName + "called");
        Salaries existingSalary = salaryService.getSalariesByEmployees(empNo);
        
        if (existingSalary != null) {
            existingSalary.setSalary(salary.getSalary());
            existingSalary.setToDate(salary.getToDate());
            Salaries updatedSalary = salaryService.updateSalary(existingSalary);
            return ResponseEntity.ok(updatedSalary);
        }
        
        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
    }

    /*
     * Delete salary by employee number and from date.
     * Returns a success message if the deletion is successful.
     */    
	@DeleteMapping("/empno/{empNo}/fromdate/{fromDate}")
    public ResponseEntity<String> deleteTitleByEmpNofromDate(
    		@RequestParam int empNo,
            @RequestParam @DateTimeFormat(pattern = "yyyy-MM-dd") LocalDate fromDate) {
		String methodName = "DeleteSalariesByempNoAndfromDate(empNo,fromDate)";
        logger.info(methodName + "called");
		salaryService.deleteByEmpNoAndFromDate(empNo, fromDate);
        return ResponseEntity.ok("Title deleted successfully");
    }
	
	/*
	 * Delete salary by from date.
	 * Returns a success message if the deletion is successful.
	 */
	@DeleteMapping("/fromdate/{fromDate}")
    public ResponseEntity<String> deleteTitleByEmpNoFromDate(
            @RequestParam @DateTimeFormat(pattern = "yyyy-MM-dd") LocalDate fromDate) {
		String methodName = "DeleteSalariesByfromDate(fromDate)";
        logger.info(methodName + "called");
		salaryService.deleteByFromDate(fromDate);
        return ResponseEntity.ok("Title deleted successfully");
    }
	
	/*
	 *  Delete salary by employee number.
	 *  Returns a success message if the deletion is successful.
	 */
	@DeleteMapping("/empno/{empNo}")
    public ResponseEntity<String> deleteTitleByEmpNo(
    		@RequestParam int empNo) {
		String methodName = "DeleteSalariesByempNo(empNo)";
        logger.info(methodName + "called");
		salaryService.deleteByEmpNo(empNo);
        return ResponseEntity.ok("Title deleted successfully");
    }
    
    
    
}
    
