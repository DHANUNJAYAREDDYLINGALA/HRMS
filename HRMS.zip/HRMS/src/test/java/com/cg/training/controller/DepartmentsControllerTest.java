package com.cg.training.controller;

import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.Arrays;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;

import com.cg.training.entities.Departments;
import com.cg.training.services.DepartmentServiceImpl;

class DepartmentsControllerTest {
	private MockMvc mockMvc;

    @Mock
    private DepartmentServiceImpl departmentServices;

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    public void testFindAlldepartments() throws Exception {
        // Mock data
        Departments department1 = new Departments("1", "Department 1", null, null);
        Departments department2 = new Departments("2", "Department 2", null, null);
        List<Departments> departmentsList = Arrays.asList(department1, department2);

        // Mock service method
        when(departmentServices.getDepartments()).thenReturn(departmentsList);

    }
    @Test
    public void testFindAllDepartmentsByDeptNo() throws Exception {
        // Mock data
        String deptNo = "D001";
        Departments department = new Departments(deptNo, "Department 1", null, null);
    //  List<Departments> departmentsList = Collections.singletonList(department);

        // Mock service method
        
        // Perform the GET request
    }
    @Test
    public void testFindAllDepartmentsByDeptName() throws Exception {
        // Mock data
        String deptName = "Department 1";
        Departments department = new Departments("D001", deptName, null, null);
       // List<Departments> departmentsList = Collections.singletonList(department);

        // Mock service method
       // when(departmentServices.getDepartmentsByDeptName(deptName)).thenReturn(departmentsList);

        // Perform the GET request
            }
    @Test
    public void testAddDepartmentManager() throws Exception {
        // Mock data
        Departments department = new Departments("D001", "Department 1", null, null);
        String requestBody = "{\"deptNo\":\"D001\",\"deptName\":\"Department 1\"}";

        // Mock service method
       // when(departmentServices.addDepartment(Mockito.any(Departments.class))).thenReturn(department);

	}
    @Test
    public void testUpdateDepartmentByDeptNo() throws Exception {
        // Mock data
        String deptNo = "D001";
        Departments department = new Departments(deptNo, "Department 1", null, null);
        String requestBody = "{\"deptNo\":\"D001\",\"deptName\":\"Updated Department\"}";
        
    }
        // Mock service method
       // when(departmentServices.updateByDeptNo(Mockito.any(Departments.class))).thenReturn(department);
    @Test
    public void testUpdateDepartmentByDeptName() throws Exception {
        // Mock data
        String deptName = "Department 1";
        Departments department = new Departments("D001", deptName, null, null);
        String requestBody = "{\"deptNo\":\"D001\",\"deptName\":\"Updated Department\"}";

        // Mock service method
       // when(departmentServices.updateByDeptName(Mockito.any(Departments.class))).thenReturn(department);


    }
   
    }


