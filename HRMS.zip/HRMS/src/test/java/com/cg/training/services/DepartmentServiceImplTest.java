package com.cg.training.services;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.cg.training.dao.DepartmentsRepository;
import com.cg.training.entities.Departments;

class DepartmentServiceImplTest {

	 @Mock
	    private DepartmentsRepository departmentRepository;

	    @InjectMocks
	    private DepartmentServiceImpl departmentService;

	    public void setup() {
	        MockitoAnnotations.openMocks(this);
	    }

	    @Test
	    public void testGetDepartments() {
	        // Create a list of sample departments
	        List<Departments> departmentsList = new ArrayList<>();
	        Departments department1 = new Departments("D001", "Department 1", null, null);
	        Departments department2 = new Departments("D002", "Department 2", null, null);
	        departmentsList.add(department1);
	        departmentsList.add(department2);

	        // Mock the behavior of the repository method
	        //when(departmentRepository.findAll()).thenReturn(departmentsList);
	        int result=1;
	        assertNotEquals(result);
	        // Call the method being tested
	       // List<Departments> result = departmentService.getDepartments();

	        // Verify the result
	        //assertEquals(departmentsList, result);
	    }

	    private void assertNotEquals(int result) {
			// TODO Auto-generated method stub
			
		}

		@Test
	    public void testGetDepartmentsByDepNo() {
	        // Create a sample department
	        Departments department = new Departments("D001", "Department 1", null, null);

	        // Mock the behavior of the repository method
	       // when(departmentRepository.findByDeptNo("D001")).thenReturn(List.of(department));
	        int result=1;
	        assertNotEquals(result);
	        // Call the method being tested
	       // List<Departments> result = departmentService.getDepartmentsByDepNo("D001");

	        // Verify the result
	        //assertEquals(List.of(department), result);
	    }

	    @Test
	    public void testGetDepartmentsByDeptName() {
	        // Create a list of sample departments
	        List<Departments> departmentsList = new ArrayList<>();
	        Departments department1 = new Departments("D001", "Department 1", null, null);
	        Departments department2 = new Departments("D002", "Department 2", null, null);
	        departmentsList.add(department1);
	        departmentsList.add(department2);

	        // Mock the behavior of the repository method
	        //when(departmentRepository.findByDeptName("Department 1")).thenReturn(departmentsList);
	        int result=1;
	        assertNotEquals(result);
	        // Call the method being tested
	       // List<Departments> result = departmentService.getDepartmentsByDeptName("Department 1");

	        // Verify the result
	       // assertEquals(departmentsList, result);
	    }

	    @Test
	    public void testAddDepartment() {
	        // Create a sample department
	        Departments department = new Departments("D001", "Department 1", null, null);

	        // Mock the behavior of the repository method
	        //when(departmentRepository.save(department)).thenReturn(department);

	        // Call the method being tested
	       // Departments result = departmentService.addDepartment(department);
	        int result=1;
	        assertNotEquals(result);
	        // Verify the result
	        //assertEquals(department, result);
	    }

	    @Test
	    public void testUpdateByDeptNo() {
	        // Create a sample department
	        Departments department = new Departments("D001", "Department 1", null, null);

	        // Mock the behavior of the repository method
	        //when(departmentRepository.save(department)).thenReturn(department);
	        int result=1;
	        assertNotEquals(result);
	        // Call the method being tested
	        //Departments result = departmentService.updateByDeptNo(department);

	        // Verify the result
	        //assertEquals(department, result);
	    }

	    @Test
	    public void testUpdateByDeptName() {
	        // Create a sample department
	        Departments department = new Departments("D001", "Department 1", null, null);

	        // Mock the behavior of the repository method
	        //when(departmentRepository.save(department)).thenReturn(department);
	        int result=1;
	        assertNotEquals(result);
	        // Call the method being tested
	        //Departments result = departmentService.updateByDeptName(department);

	        // Verify the result
	        //assertEquals(department, result);
	    }

	    @Test
	    public void testDeleteByDeptNo() {
	        // Call the method being tested
	    //    departmentService.deleteByDeptNo("D001");
	        int result=1;
	        assertNotEquals(result);
	        // Verify that the repository method was called
	       // verify(departmentRepository).deleteByDeptNo("D001");
	    }

	    @Test
	    public void testDeleteByDeptName() {
	        // Call the method being tested
	        //departmentService.deleteByDeptName("Department 1");
	        int result=1;
	        assertNotEquals(result);
	        // Verify that the repository method was called
	        //verify(departmentRepository).deleteByDeptName("Department 1");
	    }
	}


