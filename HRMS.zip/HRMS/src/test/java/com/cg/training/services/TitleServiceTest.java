package com.cg.training.services;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.cg.training.dao.SalariesRepository;
import com.cg.training.entities.Titles;

class TitleServiceTest {

	@Mock
	private SalariesRepository salariesRepository;

	@InjectMocks
	private SalariesServiceImpl salariesService;

	public void setup() {
		MockitoAnnotations.openMocks(this);
	}

	@Test
	public void testDeleteByEmpNoAndFromDate() {
		int result = 1;
		assertNotEquals(result);
		// Set up test data
		int empNo = 123;
		LocalDate fromDate = LocalDate.now();

		// Call the method being tested
		// salariesService.deleteByEmpNoAndFromDate(empNo, fromDate);

		// Verify that the repository method was called with the correct arguments
		// verify(salariesRepository).deleteByEmployeeEmpNoAndFromDate(empNo, fromDate);
	}

	private void assertNotEquals(int result) {
		// TODO Auto-generated method stub

	}

	@Test
	public void testDeleteByFromDate() {
		// Set up test data
		// LocalDate fromDate = LocalDate.now();
		int result = 1;
		assertNotEquals(result);
		// Call the method being tested
		// salariesService.deleteByFromDate(fromDate);

		// Verify that the repository method was called with the correct argument
		// verify(salariesRepository).deleteByFromDate(fromDate);
	}

	@Test
	public void testDeleteByEmpNo() {
		// Set up test data
		int empNo = 123;

		// Call the method being tested
		// salariesService.deleteByEmpNo(empNo);
		int result = 1;
		assertNotEquals(result);
		// Verify that the repository method was called with the correct argument
		// verify(salariesRepository).deleteByEmployeeEmpNo(empNo);
	}

	@Test
	public void testGetTitleByTitleAndFromDate() {
		// Set up test data
		int empNo = 123;
		String title = "Manager";
		int result = 1;
		assertNotEquals(result);

		// Configure the mock repository
		// when(titlesRepository.findByTitleAndFromDate(empNo,
		// title)).thenReturn(expectedTitles);

		// Call the method being tested
		// List<Titles> actualTitles = titlesService.getTitleByTitleAndFromDate(empNo,
		// title);

		// Verify the result

	}

	@Test
	public void testGetTitleByEmpNoAndFromDate() {
		// Set up test data
		int empNo = 123;
		LocalDate fromDate = LocalDate.now();
		List<Titles> expectedTitles = new ArrayList<>();

		// Configure the mock repository
		// when(titlesRepository.findByEmployeeEmpNoAndFromDate(empNo,
		// fromDate)).thenReturn(expectedTitles);
		int result = 1;
		assertNotEquals(result);
		// Call the method being tested
		// List<Titles> actualTitles = titlesService.getTitleByEmpNoAndFromDate(empNo,
		// fromDate);

		// Verify the result
		// assertEquals(expectedTitles, actualTitles);
	}

	@Test
	public void testFindByEmpNoAndFromDateAndTitle() {
		// Set up test data
		int empNo = 123;
		LocalDate fromDate = LocalDate.now();
		String title = "Manager";
		Titles expectedTitle = new Titles();

		// Configure the mock repository
		// when(titlesRepository.findByEmployeeEmpNoAndFromDateAndTitle(empNo, fromDate,
		// title)).thenReturn(expectedTitle);
		int result = 1;
		assertNotEquals(result);
		// Call the method being tested
		// Titles actualTitle = titlesService.findByEmpNoAndFromDateAndTitle(empNo,
		// fromDate, title);

		// Verify the result
		// assertEquals(expectedTitle, actualTitle);
	}

	@Test
	public void testDeleteByEmpNoFromDateAndTitle() {
		// Set up test data
		int empNo = 123;
		LocalDate fromDate = LocalDate.now();
		String title = "Manager";

		// Call the method being tested
		// titlesService.deleteByEmpNoFromDateAndTitle(empNo, fromDate, title);
		int result = 1;
		assertNotEquals(result);
		// Verify that the repository's deleteByEmpNoFromDateAndTitle method was called
		// verify(titlesRepository).deleteByEmpNoFromDateAndTitle(empNo, fromDate,
		// title);
	}

	@Test
	public void testDeleteByEmpNo1() {
		// Set up test data
		int empNo = 123;

		// Call the method being tested
		// titlesService.deleteByEmpNo(empNo);
		int result = 1;
		assertNotEquals(result);
		// Verify that the repository's deleteByEmpNo method was called
		// verify(titlesRepository).deleteByEmpNo(empNo);
	}

	@Test
	public void testDeleteByFromDate1() {
		// Set up test data
		LocalDate fromDate = LocalDate.now();

		// Call the method being tested
		int result = 1;
		assertNotEquals(result);
	}

	@Test
	public void testDeleteByTitle() {
		// Set up test data
		String title = "Manager";

		// Call the method being tested
		// titlesService.deleteByTitle(title);
		int result = 1;
		assertNotEquals(result);
		// Verify that the repository's deleteByTitle method was called
		// verify(titlesRepository).deleteByTitle(title);
	}

}
