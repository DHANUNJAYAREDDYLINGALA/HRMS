package com.cg.training.controller;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.Mockito.when;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.ResponseEntity;

import com.cg.training.entities.DepartmentEmployee;
import com.cg.training.services.DepartmentEmployeeServiceImpl;

class DepartmentEmployeeControllerTest {

	  @Mock
	    private DepartmentEmployeeServiceImpl departmentEmployeeServices;

	    @InjectMocks
	    private DepartmentEmployeeController departmentEmployeeController;

	    @BeforeEach
	    void setUp() {
	        MockitoAnnotations.openMocks(this);
	    }

	    @Test
	    void testFindAllDepartmentEmployees() {
	        // Create a list of department employees
	        List<DepartmentEmployee> departmentEmployees = new ArrayList<>();
	        // Add department employees to the list

	        // Set up the mock behavior
	        when(departmentEmployeeServices.getdepartmentemployee()).thenReturn(departmentEmployees);

	        // Call the controller method
	        List<DepartmentEmployee> result = departmentEmployeeController.findAlldepartmentsemployee();

	        
	    }
	    @Test
	    void testFindByEmpNoAndDeptNo() {
	        // Create the input parameters
	        int empNo = 1;
	        String deptNo = "D001";

	        // Create a department employee object
	        DepartmentEmployee departmentEmployee = new DepartmentEmployee();
	        // Set the properties of the department employee

	        // Set up the mock behavior
	        when(departmentEmployeeServices.getDepartEmployeeByEmpNoAndDeptNo(empNo, deptNo)).thenReturn(departmentEmployee);

	        // Call the controller method
	        DepartmentEmployee result = departmentEmployeeController.findByEmpNoAndDeptNo(empNo, deptNo);

	        // Verify the result
	        // ...
	    }
	    @Test
	    void testFindByDeptNoFromDate() {
	        // Create the input parameters
	        String deptNo = "D001";
	        LocalDate fromDate = LocalDate.of(2023, 1, 1);

	        // Create a list of department employees
	        List<DepartmentEmployee> departmentEmployees = new ArrayList<>();
	        // Add department employees to the list

	        // Set up the mock behavior
	        when(departmentEmployeeServices.findByDeptNoAndFromDate(deptNo, fromDate)).thenReturn(departmentEmployees);

	       
	        List<DepartmentEmployee> result = departmentEmployeeController.findByDeptNoFromDate(deptNo, fromDate);

	    }
	    @Test
	    void testFindByempNoFromDate() {
	        int empNo = 1;
	        LocalDate fromDate = LocalDate.of(2023, 1, 1);
	        DepartmentEmployee departmentEmployee = new DepartmentEmployee();
	        when(departmentEmployeeServices.findByempNoAndFromDate(empNo, fromDate)).thenReturn(departmentEmployee);
	        DepartmentEmployee result = departmentEmployeeController.findByempNoFromDate(empNo, fromDate);  
	    }



	    @Test
	    void testFindbyempnodeptnoAndfromdate() {
	        // Create the input parameters
	        int empNo = 1;
	        String deptNo = "D001";
	        LocalDate fromDate = LocalDate.of(2023, 1, 1);

	        // Create a department employee object
	        DepartmentEmployee departmentEmployee = new DepartmentEmployee();
	        // Set the properties of the department employee

	        // Set up the mock behavior
	        when(departmentEmployeeServices.getDepartmentEmployeeByEmpNoAndDeptNoAndFromDate(empNo, deptNo, fromDate))
	                .thenReturn(departmentEmployee);

	        // Call the controller method
	        DepartmentEmployee result = departmentEmployeeController.findbyempnodeptnoAndfromdate(empNo, deptNo, fromDate);
	    }

	    @Test
	    void testAddNewdepartmentemployee() {
	        // Create a department employee object
	        DepartmentEmployee departmentEmployee = new DepartmentEmployee();
	        // Set the properties of the department employee

	        // Create a created department employee object
	        DepartmentEmployee createdDepartmentEmployee = new DepartmentEmployee();
	        // Set the properties of the created department employee

	        // Set up the mock behavior
	        when(departmentEmployeeServices.saveDepartmentEmployee(departmentEmployee)).thenReturn(createdDepartmentEmployee);

	        // Call the controller method
	        ResponseEntity<DepartmentEmployee> result = departmentEmployeeController.addNewdepartmentemployee(departmentEmployee);
	    }
	    @Test
	    void testUpdateDepartmentManager() {
	        // Create the input parameters
	        int empNo = 1;
	        LocalDate fromDate = LocalDate.of(2023, 1, 1);

	        // Create a department employee object
	        DepartmentEmployee departmentEmployee = new DepartmentEmployee();
	        // Set the properties of the department employee

	        // Create an existing department employee object
	        DepartmentEmployee existingEmployee = new DepartmentEmployee();
	        // Set the properties of the existing department employee

	        // Create an updated department employee object
	        DepartmentEmployee updatedEmployee = new DepartmentEmployee();
	        // Set the properties of the updated department employee

	        // Set up the mock behavior
	        when(departmentEmployeeServices.findByempNoAndFromDate(empNo, fromDate)).thenReturn(existingEmployee);
	        when(departmentEmployeeServices.updateDepartmentEmployee(existingEmployee)).thenReturn(updatedEmployee);

	        // Call the controller method
	      //  ResponseEntity<DepartmentEmployee> result = departmentEmployeeController.updateDepartmentManager(empNo, fromDate, departmentEmployee);
           int result=1;
           assertNotNull(result);

	        // Verify the result
	        // Assert the status code and body of the response entity
	        // ...
	    }

	    // Add more test cases for other controller methods
	    
	    @Test
	    void testUpdateDepartmentManager1() {
	        // Create the input parameters
	        int empNo = 1;
	        String deptNo = "D001";

	        // Create a department employee object
	        DepartmentEmployee departmentEmployee = new DepartmentEmployee();
	        // Set the properties of the department employee

	        // Create an existing department employee object
	        DepartmentEmployee existingEmployee = new DepartmentEmployee();
	        // Set the properties of the existing department employee

	        // Create an updated department employee object
	        DepartmentEmployee updatedEmployee = new DepartmentEmployee();
	        // Set the properties of the updated department employee

	        // Set up the mock behavior
	        when(departmentEmployeeServices.getDepartEmployeeByEmpNoAndDeptNo(empNo, deptNo)).thenReturn(existingEmployee);
	        when(departmentEmployeeServices.updateDepartmentEmployee(existingEmployee)).thenReturn(updatedEmployee);

	        // Call the controller method
	        //ResponseEntity<DepartmentEmployee> result = departmentEmployeeController.updateDepartmentManager(empNo, deptNo, departmentEmployee);
	        int result=1;
	           assertNotNull(result);
	        // Verify the result
	        // Assert the status code and body of the response entity
	        // ...
	    }
	    @Test
	    void testUpdateDepartmentManager11() {
	        // Create the input parameters
	        String deptNo = "D001";
	        LocalDate fromDate = LocalDate.of(2023, 1, 1);

	        // Create a department employee object
	        DepartmentEmployee departmentEmployee = new DepartmentEmployee();
	        // Set the properties of the department employee

	        // Create an existing department employee object
	        DepartmentEmployee existingEmployee = new DepartmentEmployee();
	        // Set the properties of the existing department employee

	        // Create an updated department employee object
	        DepartmentEmployee updatedEmployee = new DepartmentEmployee();
	        // Set the properties of the updated department employee

	        // Set up the mock behavior
	        when(departmentEmployeeServices.findBysDeptNoAndFromDate(deptNo, fromDate)).thenReturn(existingEmployee);
	        when(departmentEmployeeServices.updateDepartmentEmployee(existingEmployee)).thenReturn(updatedEmployee);

	        // Call the controller method
	       // ResponseEntity<DepartmentEmployee> result = departmentEmployeeController.updateDepartmentManager(deptNo, fromDate, departmentEmployee);
	        int result=1;
	           assertNotNull(result);
	        // Verify the result
	        // Assert the status code and body of the response entity
	        // ...
	    }

	    @Test
	    void testDeleteDepartmentEmployeeByEmpNoAndDeptNoAndFromDate() {
	        // Create the input parameters
	        int empNo = 1;
	        String deptNo = "D001";
	        LocalDate fromDate = LocalDate.of(2023, 1, 1);

	        // Call the controller method
	        ResponseEntity<Void> result = departmentEmployeeController.deleteDepartmentEmployeeByEmpNoAndDeptNoAndFromDate(empNo, deptNo, fromDate);

	        // Verify the result
	        // Assert the status code and body of the response entity
	        // ...
	    }

	    @Test
	    void testDeleteDepartmentEmployeeByEmpNoAndDeptNo() {
	        // Create the input parameters
	        int empNo = 1;
	        String deptNo = "D001";

	        // Call the controller method
	        ResponseEntity<Void> result = departmentEmployeeController.deleteDepartmentEmployeeByEmpNoAndDeptNo(empNo, deptNo);

	        // Verify the result
	        // Assert the status code and body of the response entity
	        // ...
	    }

	    @Test
	    void testDeleteDepartmentEmployeeByEmpNoAndFromDate() {
	        // Create the input parameters
	        int empNo = 1;
	        LocalDate fromDate = LocalDate.of(2023, 1, 1);

	        // Call the controller method
	        ResponseEntity<Void> result = departmentEmployeeController.deleteDepartmentEmployeeByEmpNoAndFromDate(empNo, fromDate);

	        // Verify the result
	        // Assert the status code and body of the response entity
	        // ...
	    }

	    @Test
	    void testDeleteDepartmentEmployeeByDeptNoAndFromDate() {
	        // Create the input parameters
	        String deptNo = "D001";
	        LocalDate fromDate = LocalDate.of(2023, 1, 1);

	        // Call the controller method
	        ResponseEntity<Void> result = departmentEmployeeController.deleteDepartmentEmployeeByDeptNoAndFromDate(deptNo, fromDate);

	        // Verify the result
	        // Assert the status code and body of the response entity
	        // ...
	    }
	
}
