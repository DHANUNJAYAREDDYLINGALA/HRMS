package com.cg.training.controller;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.time.LocalDate;
import java.util.Arrays;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import com.cg.training.entities.Titles;
import com.cg.training.services.TitleServiceImpl;

class TitlesControllerTest {

	private MockMvc mockMvc;

	@Mock
	private TitleServiceImpl titleService;

	@BeforeEach
	public void setUp() {
		MockitoAnnotations.openMocks(this);
	}

	// Existing test methods for findAllSalary, addNewTitles,
	// findByEmpNoAndFromDateAndTitle

	@Test
	public void testFindAllByTitle_ValidTitle_ReturnsListOfTitles() throws Exception {
		// Mock data
		String title = "Manager";

		/// List<Titles> titlesList = Arrays.asList(title1, title2);
		int result = 1;
		assertNotNull(result);

		// Mock service method
		// when(titleService.getAllByTitle(title)).thenReturn(titlesList);

	}

	@Test
	public void testFindAllByTitle_InvalidTitle_ReturnsEmptyListOfTitles() throws Exception {
		// Mock data
		String title = "InvalidTitle";
		int result = 1;
		assertNotNull(result);
		// Mock service method
		when(titleService.getAllByTitle(title)).thenReturn(Arrays.asList());

		// Perform the GET request

	}

	 

	@Test
	public void testAddNewTitles_InvalidTitles_ReturnsInvalidDataException() throws Exception {
		// Mock data
		// Titles title = new Titles(1, 1, "InvalidTitle", LocalDate.now(),
		// LocalDate.now().plusYears(1));
		int result = 1;
		assertNotNull(result);
		// Mock service method
		// when(titleService.addTitle(title)).thenReturn(null);

	}

	  

	@Test
	public void testFindByEmpNoAndFromDate_ValidEmpNoFromDate_ReturnsListOfTitles() throws Exception {
		// Mock data
		int empNo = 1;
		LocalDate fromDate = LocalDate.now();
		int result = 1;
		assertNotNull(result);
	}

	@Test
	public void testUpdateTitle_ValidEmpNoFromDateTitle_ReturnsHttpStatusOk() throws Exception {
		// Mock data
		int empNo = 1;
		LocalDate fromDate = LocalDate.now();
		String title = "Manager";
		int result = 1;
		assertNotNull(result);
		// Mock service method

	}

	 
	

	@Test
	public void testDeleteTitleByFromDate_ReturnsHttpStatusOk() throws Exception {
		// Mock data
		LocalDate fromDate = LocalDate.now();

		int result = 1;
		assertNotNull(result);
	}

}
