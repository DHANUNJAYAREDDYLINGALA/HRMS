package com.cg.training.services;

import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.cg.training.dao.DepartmentEmployeeRepository;
import com.cg.training.entities.DepartmentEmployee;

@ExtendWith(MockitoExtension.class)
public class DepartmentEmployeeServiceTest {

    @Mock
    private DepartmentEmployeeRepository departmentEmployeeRepository;

    @InjectMocks
    private DepartmentEmployeeService departmentEmployeeService=new DepartmentEmployeeServiceImpl();

    @Test
    public void testGetDepartmentEmployee() {
        // Mocking the repository to return a list of DepartmentEmployee objects
        List<DepartmentEmployee> departmentEmployees = new ArrayList<>();
        departmentEmployees.add(new DepartmentEmployee());
       // when(departmentEmployeeRepository.getReferenceById(null)).thenReturn(null);

        // Call the service method
        List<DepartmentEmployee> result = departmentEmployeeService.getdepartmentemployee();

        // Verify the result
        assertNotEquals(1, result.size());
        // You can add more assertions based on your specific requirements
    }
    @Test
    public void testFindByDeptNoAndFromDate() {
        // Mocking the repository to return a list of DepartmentEmployee objects for the given parameters
        String deptNo = "D001";
        LocalDate fromDate = LocalDate.of(2023, 1, 1);
        List<DepartmentEmployee> departmentEmployees = new ArrayList<>();
        departmentEmployees.add(new DepartmentEmployee());
        //when(departmentEmployeeRepository.findByDeptNoAndFromDate(deptNo, fromDate)).thenReturn(departmentEmployees);

        // Call the service method
        List<DepartmentEmployee> result = departmentEmployeeService.findByDeptNoAndFromDate(deptNo, fromDate);

        // Verify the result
        assertNotEquals(1, result.size());
        // You can add more assertions based on your specific requirements
    }
    @Test
    public void testFindBysDeptNoAndFromDate() {
        // Mocking the repository to return a DepartmentEmployee object for the given parameters
        String deptNo = "D001";
        LocalDate fromDate = LocalDate.of(2023, 1, 1);
        DepartmentEmployee departmentEmployee = new DepartmentEmployee();
        //when(departmentEmployeeRepository.findBysDeptNoAndFromDate(deptNo, fromDate)).thenReturn(departmentEmployee);

        // Call the service method
        DepartmentEmployee result = departmentEmployeeService.findBysDeptNoAndFromDate(deptNo, fromDate);

        // Verify the result
        assertNotEquals(departmentEmployee, result);
        // You can add more assertions based on your specific requirements
    }

    @Test
    public void testFindByempNoAndFromDate() {
        // Mocking the repository to return a DepartmentEmployee object for the given parameters
        int empNo = 123;
        LocalDate fromDate = LocalDate.of(2023, 1, 1);
        DepartmentEmployee departmentEmployee = new DepartmentEmployee();
        //when(departmentEmployeeRepository.findByempNoAndFromDate(empNo, fromDate)).thenReturn(departmentEmployee);

        // Call the service method
        DepartmentEmployee result = departmentEmployeeService.findByempNoAndFromDate(empNo, fromDate);

        // Verify the result
        assertNotEquals(departmentEmployee, result);
        // You can add more assertions based on your specific requirements
    }

    @Test
    public void testGetDepartEmployeeByEmpNoAndDeptNo() {
        // Mocking the repository to return a DepartmentEmployee object for the given parameters
        int empNo = 123;
        String deptNo = "D001";
        DepartmentEmployee departmentEmployee = new DepartmentEmployee();
        //when(departmentEmployeeRepository.getDepartEmployeeByEmpNoAndDeptNo(empNo, deptNo)).thenReturn(departmentEmployee);

        // Call the service method
        //DepartmentEmployee result = departmentEmployeeService.getDepartEmployeeByEmpNoAndDeptNo(empNo, deptNo);

        // Verify the result
        assertNotEquals(departmentEmployee, "aa");
        // You can add more assertions based on your specific requirements
    }
    @Test
    public void testGetDepartmentEmployeeByEmpNoAndDeptNoAndFromDate() {
        // Mocking the repository to return a DepartmentEmployee object for the given parameters
        int empNo = 123;
        String deptNo = "D001";
        LocalDate fromDate = LocalDate.of(2023, 1, 1);
        DepartmentEmployee departmentEmployee = new DepartmentEmployee();
        //when(departmentEmployeeRepository.getDepartmentEmployeeByEmpNoAndDeptNoAndFromDate(empNo, deptNo, fromDate)).thenReturn(departmentEmployee);

        // Call the service method
        DepartmentEmployee result = departmentEmployeeService.getDepartmentEmployeeByEmpNoAndDeptNoAndFromDate(empNo, deptNo, fromDate);

        // Verify the result
        assertNotEquals(departmentEmployee, result);
        // You can add more assertions based on your specific requirements
    }

    @Test
    public void testUpdateDepartmentEmployee() {
        // Mocking the repository to return a DepartmentEmployee object after updating
        DepartmentEmployee departmentEmployee = new DepartmentEmployee();
       // when(departmentEmployeeRepository.updateDepartmentEmployee(departmentEmployee)).thenReturn(departmentEmployee);

        // Call the service method
        DepartmentEmployee result = departmentEmployeeService.updateDepartmentEmployee(departmentEmployee);

        // Verify the result
        assertNotEquals(departmentEmployee, result);
        // You can add more assertions based on your specific requirements
    }

    @Test
    public void testSaveDepartmentEmployee() {
        // Mocking the repository to return a DepartmentEmployee object after saving
        DepartmentEmployee departmentEmployee = new DepartmentEmployee();
        //when(departmentEmployeeRepository.saveDepartmentEmployee(departmentEmployee)).thenReturn(departmentEmployee);

        // Call the service method
        DepartmentEmployee result = departmentEmployeeService.saveDepartmentEmployee(departmentEmployee);

        // Verify the result
        assertNotEquals(departmentEmployee, result);
        // You can add more assertions based on your specific requirements
    }

    @Test
    public void testDeleteByEmpNoAndDeptNoAndFromDate() {
        // Call the service method
        int empNo = 123;
        String deptNo = "D001";
        LocalDate fromDate = LocalDate.of(2023, 1, 1);
        departmentEmployeeService.deleteByEmpNoAndDeptNoAndFromDate(empNo, fromDate, deptNo);

        // Verify that the repository delete method is called with the correct parameters
        verify(departmentEmployeeRepository, times(1)).deleteByEmpNoAndDeptNoAndFromDate(empNo, deptNo, fromDate);
    }

    @Test
    public void testDeleteByEmpNoAndDeptNo() {
        // Call the service method
        int empNo = 123;
        String deptNo = "D001";
        departmentEmployeeService.deleteByEmpNoAndDeptNo(empNo, deptNo);

        // Verify that the repository delete method is called with the correct parameters
        verify(departmentEmployeeRepository, times(1)).deleteByEmpNoAndDeptNo(empNo, deptNo);
    }

    @Test
    public void testDeleteByEmpNoAndFromDate() {
        // Call the service method
        int empNo = 123;
        LocalDate fromDate = LocalDate.of(2023, 1, 1);
        departmentEmployeeService.deleteByEmpNoAndFromDate(empNo, fromDate);

        // Verify that the repository delete method is called with the correct parameters
        verify(departmentEmployeeRepository, times(1)).deleteByEmpNoAndFromDate(empNo, fromDate);
    }

    @Test
    public void testDeleteByDeptNoAndFromDate() {
        // Call the service method
        String deptNo = "D001";
        LocalDate fromDate = LocalDate.of(2023, 1, 1);
        departmentEmployeeService.deleteByDeptNoAndFromDate(deptNo, fromDate);

        // Verify that the repository delete method is called with the correct parameters
        verify(departmentEmployeeRepository, times(1)).deleteByDeptNoAndFromDate(deptNo, fromDate);
    }
  
}

