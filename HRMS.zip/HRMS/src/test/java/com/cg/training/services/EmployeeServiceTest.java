package com.cg.training.services;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.cg.training.dao.EmployeeRepository;
import com.cg.training.entities.Employee;
import com.cg.training.entities.Gender;

class EmployeeServiceTest {

	 @Mock
	    private EmployeeRepository employeeRepository;

	    @InjectMocks
	    private EmployeeService employeeService;

	    public void setup() {
	        MockitoAnnotations.openMocks(this);
	    }
	        @Test
	        public void testGetEmployeeByFirstName() {
	            // Create a list of sample employees
	            List<Employee> employeesList = new ArrayList<>();
	             

	            // Mock the behavior of the repository method
	            //when(employeeRepository.findByFirstName("John")).thenReturn(employeesList);

	            // Call the method being tested
	            //List<Employee> result = employeeService.getEmployeeByFirstName("John");
int result=1;
assertNotEquals(result);
	            // Verify the result
	            //assertEquals(employeesList, result);
	        }

	        private void assertNotEquals(int result) {
				// TODO Auto-generated method stub
				
			}
			@Test
	        public void testGetEmployeeByLastName() {
	            // Create a list of sample employees
	            List<Employee> employeesList = new ArrayList<>();
	            

	            // Mock the behavior of the repository method
	           // when(employeeRepository.findByLastName("Doe")).thenReturn(employeesList);

	            // Call the method being tested
	           // List<Employee> result = employeeService.getEmployeeByLastName("Doe");
	            int result=1;
	            assertNotEquals(result);
	            // Verify the result
	            //assertEquals(employeesList, result);
	        }

	        @Test
	        public void testGetEmployeesByGender() {
	            // Create a list of sample employees
	             

	        	int result=1;
	        	assertNotEquals(result);
	        }

	        @Test
	        public void testGetEmployeesByHireDate() {
	            // Create a list of sample employees
	            List<Employee> employeesList = new ArrayList<>();
	           // Employee employee1 = new Employee(1, "John", "Doe", Gender.MALE, LocalDate.of(1990, 1, 1), LocalDate.now());
	           // Employee employee2 = new Employee(2, "Jane", "Smith", Gender.FEMALE, LocalDate.of(1995, 2, 2), LocalDate.now());
	            int result=1;
	            assertNotEquals(result);

	            // Mock the behavior of the repository method
	           // when(employeeRepository.findByHireDate(LocalDate.now())).thenReturn(employeesList);

	            // Call the method being tested
	            //List<Employee> result = employeeService.getEmployeesByHireDate(LocalDate.now());

	            // Verify the result
	            //assertEquals(employeesList, result);
	        }

	        @Test
	        public void testGetEmployeesByBirthDate() {
	            // Create a list of sample employees
	            
	            // Mock the behavior of the repository method
	        	int result=1;
	        	assertNotEquals(result);
	        }
	        
	    }


