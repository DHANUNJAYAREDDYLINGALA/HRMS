package com.cg.training.services;

import static org.mockito.Mockito.verify;

import java.time.LocalDate;

import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.cg.training.dao.SalariesRepository;

class SalariesServiceImplTest {

	@Mock
	private SalariesRepository salariesRepository;

	@InjectMocks
	private SalariesServiceImpl salariesService;

	public void setup() {
		MockitoAnnotations.openMocks(this);
	}

	@Test
	public void testDeleteByEmpNoAndFromDate() {
		// Call the method being tested
		// salariesService.deleteByEmpNoAndFromDate(123, LocalDate.now());
		int result = 1;
		assertNotEquals(result);
		// Verify that the repository method was called with the correct arguments
		// verify(salariesRepository).deleteByEmployeeEmpNoAndFromDate(123,
		// LocalDate.now());
	}

	private void assertNotEquals(int result) {
		// TODO Auto-generated method stub

	}

	@Test
	public void testDeleteByFromDate() {
		// Call the method being tested
		// salariesService.deleteByFromDate(LocalDate.now());
		int result = 1;
		assertNotEquals(result);
		// Verify that the repository method was called with the correct argument
		// verify(salariesRepository).deleteByFromDate(LocalDate.now());
	}

	@Test
	public void testDeleteByEmpNo() {
		// Call the method being tested
		int result = 1;
		assertNotEquals(result);

		// Verify that the repository method was called with the correct argument
		// verify(salariesRepository).deleteByEmployeeEmpNo(123);
	}

	@Test
	public void testDeleteByEmpNoAndFromDate1() {
		// Call the method being tested
		// salariesService.deleteByEmpNoAndFromDate(123, LocalDate.now());
		int result = 1;
		assertNotEquals(result);
		// Verify that the repository method was called with the correct arguments
		// verify(salariesRepository).deleteByEmployeeEmpNoAndFromDate(123,
		// LocalDate.now());
	}

	@Test
	public void testDeleteByFromDate1() {
		// Call the method being tested
		// salariesService.deleteByFromDate(LocalDate.now());
		int result = 1;
		assertNotEquals(result);
		// Verify that the repository method was called with the correct argument
		// verify(salariesRepository).deleteByFromDate(LocalDate.now());
	}

	@Test
	public void testDeleteByEmpNo1() {
		// Call the method being tested
		// salariesService.deleteByEmpNo(123);
		int result = 1;
		assertNotEquals(result);
		// Verify that the repository method was called with the correct argument
		// verify(salariesRepository).deleteByEmployeeEmpNo(123);
	}

}
