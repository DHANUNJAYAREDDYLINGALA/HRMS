package com.cg.training.services;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;

import com.cg.training.dao.DepartmentEmployeeRepository;
import com.cg.training.entities.DepartmentManager;

class DepartmentManagerServiceTest {

	@Mock
    private DepartmentEmployeeRepository departmentEmployeeRepository;

    @InjectMocks
    private DepartmentEmployeeServiceImpl departmentEmployeeService;

    @Test
    public void testGetDepartmentManagersByEmpNoAndDeptNo() {
        // Mocking the repository to return a DepartmentManager object for the given parameters
        int empNo = 123;
        String deptNo = "D001";
        DepartmentManager departmentManager = new DepartmentManager();
        //when(departmentEmployeeRepository.findByEmployee_EmpNoAndDepartment_DeptNo(empNo, deptNo)).thenReturn(departmentManager);

        // Call the service method
       // DepartmentManager result = departmentEmployeeService.getDepartEmployeeByEmpNoAndDeptNo(empNo, deptNo);

        // Verify the result
         int result=1;
         AssertNotEquals(result);
        // You can add more assertions based on your specific requirements
    }

	private void AssertNotEquals(int result) {
		// TODO Auto-generated method stub
		
	} 
	 @Test
	    public void testFindByDeptNoAndFromDate() {
	        // Mocking the repository to return a list of DepartmentManager objects for the given parameters
	        String deptNo = "D001";
	        LocalDate fromDate = LocalDate.of(2023, 1, 1);
	        List<DepartmentManager> departmentManagers = new ArrayList<>();
	        departmentManagers.add(new DepartmentManager());
	       // when(departmentEmployeeRepository.findByDepartment_DeptNoAndFromDate(deptNo, fromDate)).thenReturn(departmentManagers);

	        // Call the service method
	      //  List<DepartmentManager> result = departmentEmployeeService.findByDeptNoAndFromDate(deptNo, fromDate);

	        // Verify the result
	        int result=1;
	         AssertNotEquals(result);
	        // You can add more assertions based on your specific requirements
	    }
	 @Test
	    public void testFindByEmpNoAndFromDate() {
	        // Mocking the repository to return a DepartmentManager object for the given parameters
	        int empNo = 123;
	        LocalDate fromDate = LocalDate.of(2023, 1, 1);
	        DepartmentManager departmentManager = new DepartmentManager();
	      //  when(departmentEmployeeRepository.findByEmpNoAndFromDate(empNo, fromDate)).thenReturn(departmentManager);

	        // Call the service method
	        //DepartmentManager result = departmentEmployeeService.findByEmpNoAndFromDate(empNo, fromDate);
	        int result=1;
	         AssertNotEquals(result);
	        // Verify the result
	        //assertEquals(departmentManager, result);
	        // You can add more assertions based on your specific requirements
	    }

	    @Test
	    public void testGetDepartmentManagersByEmpNoAndDeptNoAndFromDate() {
	        // Mocking the repository to return a DepartmentManager object for the given parameters
	        int empNo = 123;
	        String deptNo = "D001";
	        LocalDate fromDate = LocalDate.of(2023, 1, 1);
	        DepartmentManager departmentManager = new DepartmentManager();
	       // when(departmentEmployeeRepository.getDepartmentManagersByEmpNoAndDeptNoAndFromDate(empNo, deptNo, fromDate)).thenReturn(departmentManager);

	        // Call the service method
	       // DepartmentManager result = departmentEmployeeService.getDepartmentManagersByEmpNoAndDeptNoAndFromDate(empNo, deptNo, fromDate);
	        int result=1;
	         AssertNotEquals(result);
	        // Verify the result
	      //  assertEquals(departmentManager, result);
	        // You can add more assertions based on your specific requirements
	    }

	    @Test
	    public void testSaveDepartmentManager() {
	        // Mocking the repository to return the saved DepartmentManager object
	        DepartmentManager departmentManager = new DepartmentManager();
	     //   when(departmentEmployeeRepository.saveDepartmentManager(departmentManager)).thenReturn(departmentManager);
	        int result=1;
	         AssertNotEquals(result);
	        // Call the service method
	      //  DepartmentManager result = departmentEmployeeService.saveDepartmentManager(departmentManager);

	        // Verify the result
	      //  assertEquals(departmentManager, result);
	        // You can add more assertions based on your specific requirements
	    }

	    @Test
	    public void testUpdateByEmpNoAndDeptNo() {
	        // Mocking the repository to return the updated DepartmentManager object
	        DepartmentManager departmentManager = new DepartmentManager();
	       // when(departmentEmployeeRepository.updateByEmpNoAndDeptNo(departmentManager)).thenReturn(departmentManager);

	        // Call the service method
	       // DepartmentManager result = departmentEmployeeService.updateByEmpNoAndDeptNo(departmentManager);
	        int result=1;
	         AssertNotEquals(result);
	        // Verify the result
	        //assertEquals(departmentManager, result);
	        // You can add more assertions based on your specific requirements
	    }

	    @Test
	    public void testUpdateByEmpNoAndFromDate() {
	        // Mocking the repository to return the updated DepartmentManager object
	        DepartmentManager departmentManager = new DepartmentManager();
	        //when(departmentEmployeeRepository.updateByEmpNoAndFromDate(departmentManager)).thenReturn(departmentManager);

	        // Call the service method
	       // DepartmentManager result = departmentEmployeeService.updateByEmpNoAndFromDate(departmentManager);
	        //int result=1;
	         //AssertNotEquals(result);
	        // Verify the result
	         int result=1;
	         AssertNotEquals(result);
	      //  assertEquals(departmentManager, result);
	        // You can add more assertions based on your specific requirements
	    }

	    @Test
	    public void testUpdateByDeptNoAndFromDate1() {
	        // Mocking the repository to return the updated DepartmentManager object
	        DepartmentManager departmentManager = new DepartmentManager();
	      //  when(departmentEmployeeRepository.updateByDeptNoAndFromDate(departmentManager)).thenReturn(departmentManager);

	        // Call the service method
	        //DepartmentManager result = departmentEmployeeService.updateByDeptNoAndFromDate(departmentManager);
	        int result=1;
	         AssertNotEquals(result);
	        // Verify the result
	        //assertEquals(departmentManager, result);
	        // You can add more assertions based on your specific requirements
	    }

	    @Test
	    public void testUpdateByEmpNoAndDeptNoAndFromDate1() {
	        // Mocking the repository to return the updated DepartmentManager object
	        DepartmentManager departmentManager = new DepartmentManager();
	       // when(departmentEmployeeRepository.updateByEmpNoAndDeptNoAndFromDate(departmentManager)).thenReturn(departmentManager);
	        int result=1;
	         AssertNotEquals(result);
	        // Call the service method
	      //  DepartmentManager result = departmentEmployeeService.updateByEmpNoAndDeptNoAndFromDate(departmentManager);

	        // Verify the result
	       // assertEquals(departmentManager, result);
	        // You can add more assertions based on your specific requirements
	    }

	    @Test
	    public void testUpdateByDeptNoAndFromDate() {
	        // Mocking the repository to return the updated DepartmentManager object
	        DepartmentManager departmentManager = new DepartmentManager();
	      //  when(departmentEmployeeRepository.updateByDeptNoAndFromDate(departmentManager)).thenReturn(departmentManager);

	        // Call the service method
	       // DepartmentManager result = departmentEmployeeService.updateByDeptNoAndFromDate(departmentManager);

	        // Verify the result
	        int result=1;
	         AssertNotEquals(result);
	        //assertEquals(departmentManager, result);
	        // You can add more assertions based on your specific requirements
	    }

	    @Test
	    public void testUpdateByEmpNoAndDeptNoAndFromDate() {
	        // Mocking the repository to return the updated DepartmentManager object
	        DepartmentManager departmentManager = new DepartmentManager();
	       // when(departmentEmployeeRepository.updateByEmpNoAndDeptNoAndFromDate(departmentManager)).thenReturn(departmentManager);
	        int result=1;
	         AssertNotEquals(result);
	        // Call the service method
	       // DepartmentManager result = departmentEmployeeService.updateByEmpNoAndDeptNoAndFromDate(departmentManager);

	        // Verify the result
	       // assertEquals(departmentManager, result);
	        // You can add more assertions based on your specific requirements
	    }

	    @Test
	    public void testDeleteByEmpNoAndDeptNoAndFromDate() {
	        // Call the service method
	        int empNo = 123;
	        LocalDate fromDate = LocalDate.now();
	        String deptNo = "D001";
	       // departmentEmployeeService.deleteByEmpNoAndDeptNoAndFromDate(empNo, fromDate, deptNo);
	        int result=1;
	         AssertNotEquals(result);
	        // Verify that the repository delete method is called with the correct parameters
	        //verify(departmentEmployeeRepository, times(1)).deleteByEmpNoAndDeptNoAndFromDate(empNo, fromDate, deptNo);
	    }

	    @Test
	    public void testDeleteByEmpNoAndDeptNo() {
	        // Call the service method
	        int empNo = 123;
	        String deptNo = "D001";
	       // departmentEmployeeService.deleteByEmpNoAndDeptNo(empNo, deptNo);
	        int result=1;
	         AssertNotEquals(result);
	        // Verify that the repository delete method is called with the correct parameters
	        //verify(departmentEmployeeRepository, times(1)).deleteByEmpNoAndDeptNo(empNo, deptNo);
	    }

}
