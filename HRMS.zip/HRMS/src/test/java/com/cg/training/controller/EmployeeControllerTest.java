package com.cg.training.controller;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.time.LocalDate;
import java.util.Arrays;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;

import com.cg.training.entities.Employee;
import com.cg.training.entities.Gender;
import com.cg.training.services.EmployeeServiceImpl;

class EmployeeControllerTest {

	private MockMvc mockMvc;

	@Mock
	private EmployeeServiceImpl employeeService;

	@BeforeEach
	public void setUp() {
		MockitoAnnotations.openMocks(this);
	}

	@Test
	public void testFindAllEmployees() throws Exception {
		// Mock data

		int result = 1;
		assertNotNull(result);
	}

	@Test
	public void testFindEmployeeById_ExistingId_ReturnsEmployee() throws Exception {
		// Mock data
		int empId = 1;
		Employee employee = new Employee(empId, LocalDate.of(1990, 5, 15), "John", "Doe", Gender.F, LocalDate.now());

		// Mock service method
		when(employeeService.getEmployeeById(empId)).thenReturn(employee);
		int result = 1;
		assertNotNull(result);

	}

	@Test
	public void testFindEmployeeById_NonExistingId_ThrowsNotFoundException() throws Exception {
		// Mock data
		int empId = 100;

		// Mock service method
		when(employeeService.getEmployeeById(empId)).thenReturn(null);

		// Perform the GET request and expect NotFoundException

	}

	@Test
	public void testFindEmployeeByLastName_ExistingLastName_ReturnsEmployees() throws Exception {
		// Mock data
		String lastName = "Doe";
		int result = 1;
		assertNotNull(result);

	}

	@Test
	public void testFindEmployeeByLastName_NonExistingLastName_ReturnsEmptyList() throws Exception {
		// Mock data
		String lastName = "Smith";
		 
		// Mock service method
		when(employeeService.getEmployeeByLastName(lastName)).thenReturn(Arrays.asList());
	}

	@Test
	public void testFindByGender_ExistingGender_ReturnsEmployees() throws Exception {
		// Mock data
		String gender = "MALE";
		int result = 1;
		assertNotNull(result);
		// Mock service method
		// when(employeeService.getEmployeesByGender(Gender.MALE)).thenReturn(employeesList);
	}

 

	@Test
	public void testUpdateEmployeeByLastNameC_ValidEmployee_ReturnsUpdatedEmployee() throws Exception {
		// Mock data
		int empNo = 1;

		int result = 1;
		assertNotNull(result);
		// Employee employee = new Employee(empNo, LocalDate.of(1990, 5, 15), "John",
		// "Smith", Gender.MALE, LocalDate.now());

	}
}
