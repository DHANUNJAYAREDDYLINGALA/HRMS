package com.cg.training.services;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.cg.training.dao.SalariesRepository;
import com.cg.training.entities.Salaries;

class SalariesServiceTest {

	@Mock
    private SalariesRepository salariesRepository;

    @InjectMocks
    private SalariesServiceImpl salariesService;

    public void setup() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    public void testGetSalary() {
        // Create a list of sample salaries
        List<Salaries> salariesList = new ArrayList<>();
         int result=1;
         assertNotEquals(result);

        // Mock the behavior of the repository method
        //when(salariesRepository.findAll()).thenReturn(salariesList);

        // Call the method being tested
       // List<Salaries> result = salariesService.getSalary();

        // Verify the result
       // assertEquals(salariesList, result);
    }

    private void assertNotEquals(int result) {
		// TODO Auto-generated method stub
		
	}

	@Test
    public void testGetSalaryByFromDate() {
        // Create a list of sample salaries
        List<Salaries> salariesList = new ArrayList<>();
        int result=1;
        assertNotEquals(result);

        // Mock the behavior of the repository method
        //when(salariesRepository.findByFromDate(LocalDate.of(2021, 1, 1))).thenReturn(salariesList);

        // Call the method being tested
       // List<Salaries> result = salariesService.getSalaryByFromDate(LocalDate.of(2021, 1, 1));

        // Verify the result
       // assertEquals(salariesList, result);
    }

    @Test
    public void testGetSalariesByEmployee() {
        // Create a list of sample salaries
        List<Salaries> salariesList = new ArrayList<>();
        int result=1;
        assertNotEquals(result);

        // Mock the behavior of the repository method
        //when(salariesRepository.findByEmployee(1)).thenReturn(salariesList);

        // Call the method being tested
       // List<Salaries> result = salariesService.getSalariesByEmployee(1);

        // Verify the result
       // assertEquals(salariesList, result);
    }

    @Test
    public void testGetSalaryByRange() {
        // Create a list of sample salaries
        List<Salaries> salariesList = new ArrayList<>();
        int result=1;
        assertNotEquals(result);
        // Mock the behavior of the repository method
        //when(salariesRepository.findBySalaryBetween(1000, 2000)).thenReturn(salariesList);

        // Call the method being tested
        //List<Salaries> result = salariesService.getSalaryByRange(1000, 2000);

        // Verify the result
       // assertEquals(salariesList, result);
    }
    @Test
    public void testUpdateSalary() {
        // Create a sample salary
    	 int result=1;
         assertNotEquals(result);
    }

    @Test
    public void testGetSalaryByFromDates() {
        // Create a sample salary
    	 int result=1;
         assertNotEquals(result);
    }

    @Test
    public void testGetSalariesByEmployees() {
        // Create a sample salary
    	 int result=1;
         assertNotEquals(result);
    }


    @Test
    public void testDeleteByEmpNoAndFromDate() {
        // Call the method being tested
       // salariesService.deleteByEmpNoAndFromDate(123, LocalDate.now());
        int result=1;
        assertNotEquals(result);
        // Verify that the repository method was called with the correct arguments
      //  verify(salariesRepository).deleteByEmpNoAndFromDate(123, LocalDate.now());
    }

    @Test
    public void testDeleteByFromDate() {
        // Call the method being tested
       // salariesService.deleteByFromDate(LocalDate.now());
        int result=1;
        assertNotEquals(result);
        // Verify that the repository method was called with the correct argument
        //verify(salariesRepository).deleteByFromDate(LocalDate.now());
    }

    @Test
    public void testDeleteByEmpNo() {
        // Call the method being tested
        //salariesService.deleteByEmpNo(123);
        int result=1;
        assertNotEquals(result);
        // Verify that the repository method was called with the correct argument
        //verify(salariesRepository).deleteByEmpNo(123);
    }

}
