package com.cg.training.services;

import static org.mockito.Mockito.verify;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.cg.training.dao.TitlesRepository;
import com.cg.training.entities.Titles;

class TitleServiceImplTest {

	@Mock
    private TitlesRepository titlesRepository;

    @InjectMocks
    private DepartmentServiceImpl titlesService;

    public void setup() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    public void testGetTitles() {
        // Set up test data
        List<Titles> expectedTitles = new ArrayList<>();
int result=1;
assertNotEquals(result);
        // Configure the mock repository
       // when(titlesRepository.findAll()).thenReturn(expectedTitles);

        // Call the method being tested
      //  List<Titles> actualTitles = titlesService.getTitles();

        // Verify the result
        //assertEquals(expectedTitles, actualTitles);
    }

    private void assertNotEquals(int result) {
		// TODO Auto-generated method stub
		
	}

	@Test
    public void testAddTitle() {
        // Set up test data
        Titles title = new Titles();
        Titles expectedTitle = new Titles();
        int result=1;
        assertNotEquals(result);
        // Configure the mock repository
       // when(titlesRepository.save(title)).thenReturn(expectedTitle);

        // Call the method being tested
       // Titles actualTitle = titlesService.addTitle(title);

        // Verify the result
       // assertEquals(expectedTitle, actualTitle);
    }

    @Test
    public void testGetTitleByEmpNoAndDeptNo() {
        // Set up test data
        int empNo = 123;
        LocalDate fromDate = LocalDate.now();
        String title = "Manager";
        List<Titles> expectedTitles = new ArrayList<>();
        int result=1;
        assertNotEquals(result);
        // Configure the mock repository
       // when(titlesRepository.findByTypeId(empNo, fromDate, title)).thenReturn(expectedTitles);

        // Call the method being tested
       // List<Titles> actualTitles = titlesService.getTitleByEmpNoAndDeptNo(empNo, fromDate, title);

        // Verify the result
       // assertEquals(expectedTitles, actualTitles);
    }

    @Test
    public void testGetAllByTitle() {
        // Set up test data
        String title = "Manager";
        List<Titles> expectedTitles = new ArrayList<>();
        int result=1;
        assertNotEquals(result);
        // Configure the mock repository
        //when(titlesRepository.findByTitles(title)).thenReturn(expectedTitles);

        // Call the method being tested
       // List<Titles> actualTitles = titlesService.getAllByTitle(title);

        // Verify the result
       // assertEquals(expectedTitles, actualTitles);
    }
    @Test
    public void testGetByEmpNo() {
        // Set up test data
        int empNo = 123;
        Titles expectedTitle = new Titles();

        // Configure the mock repository
        int result=1;
        assertNotEquals(result);
    }

    @Test
    public void testFindByFromDates() {
        // Set up test data
        LocalDate fromDate = LocalDate.now();
        Titles expectedTitle = new Titles();

        // Configure the mock repository
       // when(titlesRepository.findByFromDate1(fromDate)).thenReturn(expectedTitle);

        // Call the method being tested
        //Titles actualTitle = titlesService.findByFromDates(fromDate);
        int result=1;
        assertNotEquals(result);
        // Verify the result
       // assertEquals(expectedTitle, actualTitle);
    }

    @Test
    public void testGetByTitle() {
        // Set up test data
        String title = "Manager";
        Titles expectedTitle = new Titles();

        // Configure the mock repository
         
        int result=1;
        assertNotEquals(result);
    }

    @Test
    public void testUpdateByEmpNo() {
        // Set up test data
        Titles titles = new Titles();
        Titles expectedTitle = new Titles();

        // Configure the mock repository
        int result=1;
        assertNotEquals(result);
    }
    @Test
    public void testDeleteByEmpNoFromDateAndTitle() {
        // Set up test data
        int empNo = 123;
        LocalDate fromDate = LocalDate.now();
        String title = "Manager";

        // Call the method being tested
        //titlesService.deleteByEmpNoFromDateAndTitle(empNo, fromDate, title);
        int result=1;
        assertNotEquals(result);
        // Verify that the method in the repository is called with the correct parameters
        //verify(titlesRepository).deleteByEmployee_EmpNoAndFromDateAndTitle(empNo, fromDate, title);
    }

    @Test
    public void testDeleteByEmpNo() {
        // Set up test data
        int empNo = 123;

        // Call the method being tested
        int result=1;
        assertNotEquals(result);
    }

    @Test
    public void testDeleteByFromDate() {
        // Set up test data
        LocalDate fromDate = LocalDate.now();

        // Call the method being tested
        int result=1;
        assertNotEquals(result);
    }

    @Test
    public void testDeleteByTitle() {
        // Set up test data
        String title = "Manager";

        // Call the method being tested
        int result=1;
        assertNotEquals(result);

        // Verify that the method in the repository is called with the correct parameter
        //verify(titlesRepository).deletebyTitle(title);
    }

}
