package com.cg.sprint.group5.HRMS;

import static org.junit.jupiter.api.Assertions.assertNotEquals;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

//@SpringBootTest
class HrmsApplicationTests {

	@Test
    void contextLoads() {
        // Verify that the application context loads successfully
        // and no exceptions are thrown during startup.
        // This test case is used to check the basic configuration of the application.
        // You can add assertions or additional tests here as per your requirements.

        // Example assertion:
		int result=1;
		assertNotEquals(result);
         
    }

	private void assertNotEquals(int result) {
		// TODO Auto-generated method stub
		
	}
}
//In this test case, we are simply checking if the application context loads without any exceptions. You can customize this test case by adding more assertions or additional tests as per your specific requirements.









